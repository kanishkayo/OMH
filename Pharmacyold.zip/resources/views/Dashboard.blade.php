@extends('layouts.app')
@section('content')
    <Dashboard></Dashboard>
@endsection
