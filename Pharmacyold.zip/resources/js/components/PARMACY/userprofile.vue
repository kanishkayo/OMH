<template>
    <v-row no-gutters justify="center">
    <v-col cols="12" xl="7" lg="7" md="12" sm="12" xs="12">

        <v-row no-gutters>
            <v-col xl="4" lg="4" md="4" sm="12" xs="12" class="pa-5">
                <v-card style=" height=100%;

                            " >
                        <v-toolbar
                            dark
                            color="#34726f"
                            dense
                            height="36%"
                        >
                            <v-toolbar-title
                                class="headline"
                                style="margin-right: 30px"
                            >
                                <span
                                    class="font-weight-bold text--sm white--text"
                                >
                                    Add Pharmacy Stock
                                </span>
                            </v-toolbar-title>
                        </v-toolbar>

                        <v-card
                            style="
                                background-color: rgba(52,114,111,0.1);
                            "
                        >
                            <v-card-text>
                                <v-container>

                                    <v-row
                                        justify="space-around"
                                        no-gutters
                                    >
                                        <v-col cols="12">
                                            <v-text-field
                                                solo
                                                label="Item name"
                                                clearable
                                                dense
                                                v-model="item_name"

                                            ></v-text-field>
                                        </v-col>
                                    </v-row>

                                    <v-row
                                        justify="space-around"
                                        no-gutters
                                    >
                                        <v-col cols="12">
                                            <v-select
                                                :items="
                                                    subcategoryList
                                                "
                                                v-model="sub_category"
                                                label="Sub category"
                                                solo
                                                dense
                                            ></v-select>
                                        </v-col>
                                    </v-row>

                                    <v-card-actions dense>
                                        <v-spacer></v-spacer>
                                        <v-btn
                                            depressed
                                            color="#424242"
                                            dense
                                            small
                                            text
                                            @click="clearForm()"

                                        >
                                            Clear
                                        </v-btn>

                                        <v-btn
                                            depressed
                                            color="#34726f"
                                            dense
                                            small
                                            dark
                                            @click="addInventoryItem()"
                                        >
                                            Save
                                        </v-btn>
                                    </v-card-actions>
                                </v-container>
                            </v-card-text>
                        </v-card>
                    </v-card>
            </v-col>
            <v-col cols="12" xl="8" lg="8" md="8" sm="12" xs="12" class="mt-3 mx-auto rounded- align-center text-center">
                <v-card style="background-color: #424242;">
                    <v-card flat>
                        <v-data-table
                            :headers="pharmarcyStockheaders"
                            :search="search"
                            :items-per-page="5"
                            :items="pharmarcyStock"
                            dense
                            flat
                            class="elevation-1"
                            >



                            <template v-slot:activator="{ on, attrs }">

                                <v-btn
                                    class="mr-2 white--text"
                                    @click="dialogsh(item)"
                                    color="#CBAB04"
                                    v-bind="attrs"
                                    v-on="on"
                                    dense                                                                                dark
                                    x-small
                                ><v-icon dense class="white--text">
                                    mdi-information-variant </v-icon>
                                    <strong>&nbsp; view</strong>
                                </v-btn>

                            </template>


                        </v-data-table>
                    </v-card>
                </v-card>
            </v-col>
        </v-row>
    </v-col>
    <v-col cols="12" xl="5" lg="5" md="12" sm="12" xs="12">
                <v-card class="mx-3 mt-3 pa-3" :elevation="6" style="height:100%;">
                    <GmapMap
                        style="width: 100% !important; height: 85vh !important;"
                        :options="options"
                        :center="center"
                        :zoom="mapZoom"
                        ref="mapDiv"
                    >

                        <div
                        id="searchBarDiv"
                        style="margin-top: 10px;margin-left:30px;"
                        >
                            <v-toolbar dense floating v-show="setmapSearchBar">
                                <v-text-field
                                    hide-details
                                    placeholder="Search Address"
                                    single-line
                                    class="address_complete"
                                    v-model="searchAddress"
                                    id="search_address"
                                >
                                </v-text-field>

                                <!--<v-btn icon @click="locateCurrentLocation">
                                    <v-icon>my_location</v-icon>
                                </v-btn>-->
                            </v-toolbar>
                        </div>
                        <div
                        id="keyMap"
                        style="margin-bottom: 50px; margin-left:20px;"
                        >
                        <table style="background-color:#424242; padding: 0; margin: 0;">
                            <tr>
                                <td style="padding:0; margin:0;"><v-img src="/images/techMarker.png"></v-img></td>
                                <td style="padding:1; margin:0;" class="white--text"><h3>Tec Officer of Registered </h3></td>
                            </tr>
                        </table>

                        <v-btn
                        color="success"
                        fab
                        x-small
                        dark
                        @click="getRegisteredAgent"
                        >
                        reset
                        </v-btn>

                        </div>
                        <GmapInfoWindow
                            :options="infoOptions"
                            :position="infoPosition"
                            :opened="infoOpened"
                            :content="infoContent"
                            @closeclick="infoOpened = false"
                        >
                        </GmapInfoWindow>
                        <GmapMarker
                            v-for="(
                                item, key
                            ) in visualizeRegTecOfficerTbAndMap"
                            :key="key"
                            :icon="markerImg"
                            :position="getPosition(item)"
                            :clickable="true"
                            :title="item.phone_number"
                            @click="
                                toggleInfoJsonMarker(
                                    item.lat,
                                    item.lng,
                                    item,
                                    key
                                )
                            "
                        />

                    </GmapMap>
                </v-card>
            </v-col>
    </v-row>
    </template>
    <script>
    import { mapState } from 'vuex';
    import { store } from "../store/store";
        export default {
            name: "profile",

            components:{
                store,
            },

            data() {
                return {
                    user:[],
                    pharmarcyStock:[],
                    pharmarcyStockheaders: [
                    {
                    text: 'Item_name',
                    align: 'start',
                    sortable: false,
                    value: 'inventory_item_name'
                    },
                    { text: 'Stock', value: 'stock', sortable: false },
                    { text: 'Action', value: 'action', sortable: false },
                    ],

                    user_id:'',
                    id:'',

                    userRegFormData:{

                    lat:null,
                    lng:null,
                    street_address: null,
                    google_address: null,
                    province:null,
                    district: null,

                    },

                    markerImg: "../../images/techMarker.png",
                    snackbar: false,
                    snackMessage: false,
                    snackColor: "",
                    snackBarTop: true,
                    snackBarRight: false,
                    overlay: false,

                    searchAddress: null,


                    infoContent: "",
                    infoOpened: false,
                    infoOptions: {},
                    infoPosition: null,
                    infoCurrentKey:0,

                    options: {
                        controlSize: 21,
                        zoomControl: true,
                        mapTypeControl: true,
                        streetViewControl: true,
                        scaleControl: true,
                        fullscreenControl: true,
                        zoomControlOptions: {
                            position: 7,
                        },
                        streetViewControlOptions: {
                            position: 7,
                        },
                        mapTypeControlOptions: {
                            position: 3,
                        },
                        fullscreenControlOptions: {
                            position: 3,
                        },
                        scaleControlOptions: {
                            position: 7,
                        },
                    },
                    center: { lat: 7.9708759, lng: 80.2615532 },
                    GMap: null,
                    mapZoom:7.8,



                    search: '',

                }
            },
            watch: {

            },
            created(){
                this.checkLoging();

            },
            computed: {

            },

            mounted() {


            },

            methods: {

                checkLoging() {

                let user = localStorage.getItem("user");

                user = JSON.parse(user);
                alert(user.role);
                if (user.role !== "ADMIN") {
                    this.$router.back();
                } else {
                    this.user_id = user.id;
                   // alert(user_id);
                    this.user = user;
                    this.getuserStock(this.user_id);
                }
                },

                getuserStock(id){
                    //alert('kkk');
                    axios.get(`/api/pharmacy/stock/${id}`)
                    .then(response => {

                        this.pharmarcyStock = response.data.data;

                    })
                    .catch(error => {
                        console.error(error);
                    });
                }
            },


        }
    </script>
    <style>
    .user-profile-card {
      max-width: 800px;
      margin: 0 auto;
    }
    </style>
