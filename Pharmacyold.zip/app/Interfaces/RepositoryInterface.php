<?php

namespace App\Interfaces;

interface RepositoryInterface
{
    public function getAll();
}
