<?php

namespace App\Interfaces;

use Illuminate\Contracts\Pagination\Paginator;

interface UserInterface
{

    public function all(array $filterData):Paginator;
    public function update(array $data, $id);
}
