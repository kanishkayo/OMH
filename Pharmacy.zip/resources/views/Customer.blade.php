@extends('layouts.appCustomer')
@section('content')
<Dashboard></Dashboard>
@endsection
