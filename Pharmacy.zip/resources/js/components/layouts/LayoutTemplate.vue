<template>
    <div>

    </div>
</template>
<script>
    export default {

        data() {
            return {

            }
        },

        created(){
        
        },

        watch: {

        },

        methods: {
           
        },
        
        mounted() {
          
        }
    }
</script>
<style>

</style>