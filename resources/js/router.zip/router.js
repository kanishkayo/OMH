import Vue from "vue";
import Router from "vue-router";

import Login from './components/Login'
import DashboardHome from "./components/AS/Home/DashboardView.vue"
import USERREG from "./components/ADMIN/userRegistration"
import USER from "./components/ADMIN/user"
import CONTRACTOR from "./components/ADMIN/contractor"
import CHARTEDENG from "./components/ADMIN/chartedEng"
import SERVICE from "./components/ADMIN/service"
import CUSTOMERDASHBORD from "./components/CustomerDashbord";

const routes = [
    {
        path: "/",
        component: Login
    },

    {
        path:"/leco/dashboard/home",
        component: DashboardHome
    },

    {
        path:"/leco/dashboard/userRegistration",
        component: USERREG
    },

    {
        path:"/leco/dashboard/user",
        component: USER
    },

    {
        path:"/leco/dashboard/contractor",
        component: CONTRACTOR
    },

    {
        path:"/leco/dashboard/chartedEng",
        component: CHARTEDENG
    },

    {
        path:"/leco/dashboard/service",
        component: SERVICE
    },


    {
        path:"/leco/customer",
        component: CUSTOMERDASHBORD
    },



];

Vue.use(Router);

export default new Router({
    state: {
        userIsAuthorized: true,
    },
    mode: "history",
    routes
});
