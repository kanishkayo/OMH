<template>

    <v-row>
        <v-col cols="4">
            <v-stepper v-model="e1">
            <v-stepper-header >
                <v-stepper-step
                :complete="e1 > 1"
                step="1"
                color="#CBAB04"
                >
                <v-icon>mdi-account</v-icon>
                </v-stepper-step>
        
                <v-divider></v-divider>
        
                <v-stepper-step
                :complete="e1 > 2"
                step="2"
                color="#CBAB04"
                >
                <v-icon>mdi-human-greeting-proximity</v-icon> 
                </v-stepper-step>
        
                <v-divider></v-divider>
        
                <v-stepper-step step="3" color="#CBAB04">
                    <v-icon>mdi-information</v-icon>
                </v-stepper-step>
            </v-stepper-header>
        
            <v-stepper-items>
                <v-stepper-content step="1">
                
                <v-card flat class="mb-12">
                    <v-card-text>
                        <v-row no-gutters>

                            <v-col cols="12">
                                <v-select
                                    :items="role"
                                    label="Slect user role"
                                    solo
                                    dense
                                    
                                    ></v-select>
                            </v-col>
                        </v-row> 
                        <v-row justify="space-around"
                                        no-gutters>                       
                        <v-row no-gutters>
                                                    
                            <v-col cols="12"  no-gutters>
                                <v-container
                                    class="px-0"
                                    fluid
                                >
                                    <v-checkbox
                                    v-model="checkbox"
                                    :label="`Checkbox 1: ${checkbox.toString()}`"
                                    dense
                                    >
                                    <template v-slot:label>
                                    <div>It's <strong class="orange--text">LECO agent</strong></div>
                                    </template>
                                    </v-checkbox>
                                </v-container>
                                
                            </v-col>

                            
                        </v-row>
                        </v-row>

                        <v-row no-gutters >
                            <v-col
                                cols="12"
                            >
                                <v-text-field
                                    solo
                                    label="Enter full name"
                                    clearable
                                    dense
                                ></v-text-field>
                            </v-col>
                        </v-row>

                        
                        <v-row no-gutters
                        >
                            <v-col
                                cols="12"
                            >
                                <v-select
                                    :items="
                                        gender
                                    "
                                    label="Gender"
                                    solo
                                    dense
                                ></v-select>
                            </v-col>
                        </v-row>

                        <v-row no-gutters
                        >
                            <v-col
                                cols="12"
                            >
                                <v-text-field
                                    solo
                                    label="Enter NIC number"
                                    clearable
                                    dense
                                ></v-text-field>
                            </v-col>
                        </v-row>

                        <v-row no-gutters
                        >
                            <v-col
                                cols="12"
                            >
                            <v-file-input
                                label="Upload Image"
                                prepend-inner-icon="mdi-camera"
                                solo
                                dense
                                prepend-icon=""
                            ></v-file-input>
                            </v-col>
                        </v-row>
                                    
                        
                    </v-card-text>

                    <v-card-actions>
                    <v-spacer></v-spacer>
                    
                    <v-btn
                        depressed
                        color="#CBAB04"
                        @click="e1 = 2"
                        dense
                        small
                        dark
                    >
                        Next
                    </v-btn>
                    </v-card-actions>
                    
                </v-card>
        
                
                
                </v-stepper-content>
        
                <v-stepper-content step="2">
                    <v-card flat class="mb-12">
                        <v-card-text>
                        <v-row
                            justify="space-around"
                            no-gutters
                        >
                            <v-col
                                cols="12"
                            >
                                <v-text-field
                                    solo
                                    label="Phone number"
                                    clearable
                                    dense
                                ></v-text-field>
                            </v-col>
                        </v-row>

                        <v-row
                            justify="space-around"
                            no-gutters
                        >
                            <v-col
                                cols="12"
                            >
                                <v-text-field
                                    solo
                                    label="Other phone number"
                                    clearable
                                    dense
                                ></v-text-field>
                            </v-col>
                        </v-row>

                        <v-row
                            justify="space-around"
                            no-gutters
                        >
                            <v-col
                                cols="12"
                            >
                                <v-text-field
                                    solo
                                    label="Enter e-mail"
                                    clearable
                                    dense
                                ></v-text-field>
                            </v-col>
                        </v-row>

                        <v-row
                            justify="space-around"
                            no-gutters
                        >
                            <v-col
                                cols="12"
                            >
                                <v-text-field
                                    solo
                                    label="Street address"
                                    clearable
                                    dense
                                ></v-text-field>
                            </v-col>
                        </v-row>

                        <v-row
                            justify="space-around"
                            no-gutters
                        >
                            <v-col
                                cols="12"
                            >
                                <v-text-field
                                    solo
                                    label="City"
                                    clearable
                                    dense
                                ></v-text-field>
                            </v-col>
                        </v-row>

                        <v-row
                            justify="space-around"
                            no-gutters
                        >
                            <v-col
                                cols="12"
                            >
                                <v-tooltip bottom>
                                    <template v-slot:activator="{ on, attrs }">
                                        <v-text-field
                                            v-bind="attrs"
                                            v-on="on"
                                            dense
                                            solo
                                            readonly
                                            label="Google address"
                                            prepend-inner-icon="mdi-map-marker"
                                            :rules="[
                                                (v) =>
                                                    !!v ||
                                                    'Locations is required',
                                            ]"
                                            class="pb-0 mb-0"
                                        >
                                        </v-text-field>
                                    </template>
                                    <span>Click Map</span>
                                </v-tooltip>
                            </v-col>
                        </v-row>

                        
                        </v-card-text>

                        <v-card-actions dense>
                            <v-spacer></v-spacer>
                            <v-btn
                            depressed
                            color="#CBAB04"
                            @click="e1 = 1"
                            dense
                            small
                            dark
                            text
                            >
                                Back
                            </v-btn>

                            <v-btn
                            depressed
                            color="#CBAB04"
                            @click="e1 = 3"
                            dense 
                            small
                            dark
                            >
                                Next
                            </v-btn>
                        </v-card-actions>

                    </v-card>

                        
                
                </v-stepper-content>
        
                <v-stepper-content step="3">
                    <v-card flat class="mb-12">
                                    <v-card-text>
                                
                                        <v-row justify="space-around" no-gutters
                                        >
                                            <v-col
                                                cols="7.5"
                                            >
                                            <v-subheader solo><strong>Available dates & time period</strong></v-subheader>
                                            
                                            </v-col>
                                            
                                            <v-col
                                                cols="4.5" 
                                            >
                                                <v-dialog
                                                v-model="dialogdt"
                                                width="700"
                                                >
                                                
                                                    <template v-slot:activator="{ on, attrs }">
                                                        <v-btn
                                                        
                                                        v-bind="attrs"
                                                        v-on="on"
                                                        color="#CBAB04"
                                                        class="#424242--text"
                                                        block
                                                        outlined
                                                        >
                                                        Click Me 
                                                        </v-btn>
                                                    </template>
                                                    
                                                
                                                <v-card>
                                                    <v-card-title class="text-h5 grey lighten-2">
                                                        <v-row justify="space-around" no-gutters>
                                                            <v-col cols="12"><v-spacer></v-spacer></v-col>
                                                            <v-col cols="4">
                                                                <v-subheader solo dense ><strong>Day</strong></v-subheader>
                                                            </v-col>

                                                            <v-col cols="4">
                                                                <v-subheader solo dense><strong>Start time</strong></v-subheader>
                                                            </v-col>

                                                            <v-col cols="4">
                                                                <v-subheader solo dense><strong>End time</strong></v-subheader>
                                                            </v-col>

                                                        </v-row>
                                                    </v-card-title>

                                                    <v-row justify="space-around" no-gutters>
                                                        <v-row v-for="(
                                                            singleItem, k
                                                        ) in importPermitMultipleDocAttachments"
                                                        :key="k">
                                                            <v-col cols="4" class="d-flex">
                                                                <v-col cols="10">
                                                                    <v-select
                                                                    v-model="singleItem.days"
                                                                    :items="days"
                                                                    label="Select day"
                                                                    dense
                                                                    menu-props="auto"
                                                                    hide-details
                                                                    single-line
                                                                    
                                                                    ></v-select>
                                                                </v-col>
                                                            </v-col>

                                                            <v-col cols="3.5" class="d-flex">
                                                                <v-menu
                                                                    ref="menu1"
                                                                    v-model="menu2"
                                                                    :close-on-content-click="false"
                                                                    :nudge-right="40"
                                                                    :return-value.sync="timeStart"
                                                                    transition="scale-transition"
                                                                    offset-y
                                                                    max-width="200px"
                                                                    min-width="200px"
                                                                >
                                                                    <template v-slot:activator="{ on, attrs }">
                                                                    <v-text-field
                                                                        v-model="timeStart"
                                                                        label="Start time"
                                                                        prepend-icon="mdi-clock-time-four-outline"
                                                                        readonly
                                                                        v-bind="attrs"
                                                                        v-on="on"
                                                                    ></v-text-field>
                                                                    </template>
                                                                    <v-time-picker
                                                                    v-if="menu2"
                                                                    v-model="timeStart"
                                                                    full-width
                                                                    @click:minute="$refs.menu1.save(timeStart)"
                                                                    ></v-time-picker>
                                                                </v-menu>
                                                                <!-- <v-menu
                                                                    ref="menuu"
                                                                    v-model="menu2"
                                                                    :close-on-content-click="false"
                                                                    :nudge-right="40"
                                                                    :return-value.sync="time"
                                                                    transition="scale-transition"
                                                                    offset-y
                                                                    max-width="290px"
                                                                    min-width="290px"
                                                                >
                                                                    <template v-slot:activator="{ on, attrs }">
                                                                    <v-text-field
                                                                        v-model="time"
                                                                        label="Start time"
                                                                        prepend-icon="mdi-clock-time-four-outline"
                                                                        readonly
                                                                        v-bind="attrs"
                                                                        v-on="on"
                                                                    ></v-text-field>
                                                                    </template>
                                                                    <v-time-picker
                                                                    v-if="menu2"
                                                                    v-model="time"
                                                                    full-width
                                                                    @click:minute="$refs.menu.save(time)"
                                                                    ></v-time-picker>
                                                                </v-menu> -->
                                                            </v-col>

                                                            <v-col cols="3.5" class="d-flex">
                                                                <v-menu
                                                                    ref="menu"
                                                                    v-model="menu3"
                                                                    :close-on-content-click="false"
                                                                    :nudge-right="40"
                                                                    :return-value.sync="time2"
                                                                    transition="scale-transition"
                                                                    offset-y
                                                                    max-width="200px"
                                                                    min-width="200px"
                                                                >
                                                                    <template v-slot:activator="{ on, attrs }">
                                                                    <v-text-field
                                                                        v-model="time2"
                                                                        label="End time"
                                                                        prepend-icon="mdi-clock-time-four-outline"
                                                                        readonly
                                                                        v-bind="attrs"
                                                                        v-on="on"
                                                                    ></v-text-field>
                                                                    </template>
                                                                    <v-time-picker
                                                                    v-if="menu3"
                                                                    v-model="time2"
                                                                    full-width
                                                                    @click:minute="$refs.menu.save(time2)"
                                                                    ></v-time-picker>
                                                                </v-menu>
                                                            </v-col>

                                                            <v-col cols="1"  class="mt-3 mx-auto rounded- align-center text-center">
                                                            
                                                                <v-btn
                                                                    x-small
                                                                    dark
                                                                    color="red darken-4"
                                                                    dense
                                                                    @click="removeImportPermitDoc(k)"
                                                                    v-show="
                                                                        k ||
                                                                        (!k &&
                                                                            importPermitMultipleDocAttachments.length >
                                                                                1)
                                                                    "
                                                                >
                                                                    <v-icon small
                                                                        >mdi-minus</v-icon
                                                                    >
                                                                </v-btn>

                                                                <v-btn
                                                                    x-small
                                                                    dark
                                                                    color="green darken-4"
                                                                    dense
                                                                    @click="addImportPermitDoc(k)"
                                                                    v-show="
                                                                        k ==
                                                                        importPermitMultipleDocAttachments.length -
                                                                            1
                                                                    "
                                                                >
                                                                    <v-icon small
                                                                        >mdi-plus</v-icon
                                                                    >
                                                                </v-btn>

                                                            </v-col>
                                                        </v-row>
                                                    </v-row>

                                                    <v-divider></v-divider>

                                                    <v-card-actions dense>
                                                    <v-spacer></v-spacer>
                                                    <v-btn
                                                        color="#CBAB04"
                                                        dark
                                                        dense
                                                        text
                                                        @click="dialogdt = false"
                                                    >
                                                        Cancel
                                                    </v-btn>

                                                    <v-btn
                                                        color="#CBAB04"
                                                        dark
                                                        dense
                                                        @click="dialogdt = false"
                                                    >
                                                        Save
                                                    </v-btn>
                                                    <v-spacer></v-spacer>
                                                    </v-card-actions>
                                                </v-card>
                                                </v-dialog>
                                            </v-col>
                                        </v-row>
                                    
                                    <v-row
                                    justify="space-around"
                                    no-gutters
                                >
                                        <v-row
                                            justify="space-around"
                                        >
                                            <v-col
                                                cols="3"
                                            >
                                            <v-subheader solo dense><strong>Experience</strong></v-subheader>
                                            
                                            </v-col>
                                            
                                            <v-col
                                                cols="4.5"
                                            >
                                                <v-select
                                                    v-model=" select "
                                                    :items="years"
                                                    label="Years"
                                                    solo
                                                    dense
                                                    menu-props="auto"
                                                    hide-details
                                                    single-line
                                                    ></v-select>
                                            </v-col>

                                            <v-col
                                                cols="4.5"
                                            >
                                            <v-select
                                                v-model=" select "
                                                :items="months"
                                                label="Months"
                                                solo
                                                dense
                                                menu-props="auto"
                                                hide-details
                                                single-line
                                                ></v-select>
                                            </v-col>
                                        
                                        </v-row>
                                    </v-row>             
                                    
                                                                       
                                    <v-row
                                        justify="space-around"
                                        no-gutters
                                    > 
                                    <v-col cols="12">
                                        <v-autocomplete
                                            v-model="service"
                                            :items="svs"
                                            dense
                                            chips
                                            small-chips
                                            label="Select provided services"
                                            multiple
                                            solo
                                            item-text="name"
                                            item-value="name"
                                            menu-props="auto"
                                            hide-details
                                            single-line
                                                
                                        >
                                    </v-autocomplete>
                                    <v-spacer></v-spacer>
                                        </v-col>
                                    </v-row>

                                    <v-row
                                        justify="space-around"
                                        no-gutters
                                    >
                                        <v-col
                                            cols="12"
                                        >
                                            <v-textarea
                                                solo
                                                dense
                                                name="input-7-4"
                                                label="Describe qualifications"
                                            >
                                            </v-textarea>
                                        </v-col>
                                    </v-row>

                                    <v-row no-gutters
                                    >
                                        <v-col
                                            cols="12"
                                        >
                                            <v-file-input
                                                dense
                                                outlined
                                                label="Attachments .pdf File"
                                                clearable
                                                prepend-inner-icon="mdi-paperclip"
                                                prepend-icon=""
                                                class="pb-0 mb-0"
                                                :show-size="1000"
                                                accept=".pdf"
                                            ></v-file-input>
                                        </v-col>
                                    </v-row>

                                </v-card-text>

                                <v-card-actions dense>
                                <v-spacer></v-spacer>
                                <v-btn
                                depressed
                                color="#CBAB04"
                                @click="e1 = 2"
                                dense
                                small
                                dark
                                text
                                >
                                    Back
                                </v-btn>

                                <v-btn
                                depressed
                                color="#CBAB04"
                                @click=" dialog = false "
                                dense
                                small
                                dark
                                >
                                Save
                                </v-btn>
                            </v-card-actions>

                                </v-card>
        
                
                </v-stepper-content>
            </v-stepper-items>
            </v-stepper>
        </v-col>
    <v-col cols="8">
        <v-col cols="12" class="mt-3 mx-auto rounded- align-center text-center"  >
            <v-img src="/images/map.jpg" ></v-img>
        </v-col>
    </v-col>

    </v-row>
  </template>

<script>

export default {
        data () {
          return {

            e1: 1,
            checkbox: false,
            role: ['Agent', 'Contractor', 'Charted Engineer'],
            gender: ['Male', 'Female'],
            show1: false,
            radios: null,
            tab: null,
            dialogdt: false,
            rules: {
              required: value => !!value || 'Required.',
              min: v => v.length >= 8 || 'Min 8 characters',
            },
            service: [],
            svs: [
            { header: 'Group 1' },
            { name: 'Service 1', group: 'Group 1'},
            { name: 'Service 2', group: 'Group 1' },
            { name: 'Service 3', group: 'Group 1'},
            { name: 'Service 4', group: 'Group 1'},
            { divider: true },
            { header: 'Group 2' },
            { name: 'Service 5', group: 'Group 2'},
            { name: 'Service 6', group: 'Group 2' },
            { name: 'Service 7', group: 'Group 2'},
            { name: 'Service 8', group: 'Group 2'},
            { divider: true },
            { header: 'Group 3' },
            { name: 'Service 9', group: 'Group 3'},
            { name: 'Service 10', group: 'Group 3' },
            { name: 'Service 11', group: 'Group 3'},
            { name: 'Service 12', group: 'Group 3'},
          ],

          importPermitMultipleDocAttachments: [
                {
                    days: "",
                    time2: null,
                    timeStart: "",
                },
            ],
          
          days: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Satuday' ],
          years: ['1 Years', '2 Years', '3 Years', '4 Years', '5 Years', '6 Years', '7 Years', '8 Years', '9 Years', '10 Years', '11 Years', '12 Years', '13 Years', '14 Years', '15 Years', '16 Years', '17 Years', '18 Years', '19 Years','20 Years'],
          months: ['1 Months', '2 Months', '3 Months', '4 Months', '5 Months', '6 Months', '7 Months', '8 Months', '9 Months', '10 Months', '11 Months'],
            
          
          menu2: false,
          menu3: false,
          time: null,
          time2: null,
          timeStart:"",
               
  
           }
        },
        methods: {
            addImportPermitDoc(index) {
            this.importPermitMultipleDocAttachments.push({
                days: "",
                time2: null,
                timeStart: "",
            });
        },

        removeImportPermitDoc(index) {
            this.importPermitMultipleDocAttachments.splice(index, 1);
        },
        },
      }
</script>