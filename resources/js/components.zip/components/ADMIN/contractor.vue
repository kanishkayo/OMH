<template>
    <v-card>
        <v-row>
            <v-col cols="12" md="5">
                
                    <!-- <v-responsive class="overflow-y-auto" max-height="661"> -->
                    
                <v-row>
                    <v-col cols="11" class="mt-3 mx-auto rounded- align-center text-center">    

                        <v-row class="pa-5">
                            <v-col cols="3">
                                <v-select
                                    v-model="service"
                                    :items="items"
                                    
                                    chips
                                    label="Services"
                                    multiple
                                    solo
                                    dense
                                ></v-select>
                            </v-col>

                            <v-col cols="3">
                                <v-select
                                    v-model="phone"
                                    :items="items"
                                    chips
                                    label="Phone no."
                                    multiple
                                    solo
                                    dense

                                ></v-select>
                            </v-col>

                            <v-col cols="3">
                                <v-select
                                    v-model="rating"
                                    :items="items"
                                    chips
                                    label="Rating"
                                    multiple
                                    dense
                                    solo
                                ></v-select>
                            </v-col>

                            <v-col cols="3">
                                <v-btn
                                    :loading="loading"
                                    :disabled="loading"
                                    color="#424242"
                                    class="white--text mt-1"
                                    @click="loader = 'loading'"
                                    
                                >
                                    Filter
                                    <template v-slot:loader>
                                        <span class="custom-loader">
                                            <v-icon light>mdi-cached</v-icon>
                                        </span>
                                    </template>
                                </v-btn>
                            </v-col>
                        </v-row>

                        <v-row no-gutters class="pa-4 pb-0">
                            <v-col
                            cols="12" xs="10" sm="10" md="10" lg="10" xl="10"
                            >
                                <v-text-field
                                    v-model="search"
                                    append-icon="mdi-magnify"
                                    label="Search"
                                    single-line
                                    hide-details
                                    clearable
                                ></v-text-field>
                            </v-col>

                            <v-col
                            cols="2"
                            class="mt-3 mx-auto rounded- align-center text-center"
                            >
                            <v-dialog v-model="dialog" fullscreen  hide-overlay >
                                <template v-slot:activator="{ on, attrs }">
                                    
                                    <v-btn
                                        color="#CBAB04"
                                        v-bind="attrs"
                                        v-on="on"
                                        class="font-weight-bold text--sm white--text"
                                        fab
                                        small

                                    >
                                    <v-icon dark bold>
                                        mdi-plus
                                    </v-icon>

                                    </v-btn>
                                </template>

                                <v-card>

                                    <v-row no-gutters>
                                        <v-toolbar
                                        dark
                                        color="#CBAB04"  dense height="36%"
                                        >
                                        <v-btn
                                            icon
                                            color="black"
                                            @click=" dialog = false "
                                        >
                                            <strong><v-icon bold>mdi-close</v-icon></strong>
                                        </v-btn>
                                        <v-toolbar-title class="headline" style="margin-right: 30px">
                                            <span class="font-weight-bold text--sm black--text">Add new contractor</span>
                                        </v-toolbar-title>
                                        <v-spacer></v-spacer>
                                        <v-toolbar-items>
                                        
                                            <v-btn
                                            
                                            text
                                            @click=" dialog = false "
                                            color="black"
                                            ><strong>Save</strong>
                                            
                                            </v-btn>
                                            
                                        </v-toolbar-items>
                                        </v-toolbar>
                                    </v-row>
                                    <v-row no-gutters>
                                        <v-col cols="4">
                                        <v-stepper v-model="e1" no-gutters>
                                        <v-stepper-header >
                                            <v-stepper-step
                                            :complete="e1 > 1"
                                            step="1"
                                            color="#CBAB04"
                                            >
                                            <v-icon>mdi-account</v-icon>
                                            </v-stepper-step>
                                    
                                            <v-divider></v-divider>
                                    
                                            <v-stepper-step
                                            :complete="e1 > 2"
                                            step="2"
                                            color="#CBAB04"
                                            >
                                            <v-icon>mdi-human-greeting-proximity</v-icon> 
                                            </v-stepper-step>
                                    
                                            <v-divider></v-divider>
                                    
                                            <v-stepper-step step="3" color="#CBAB04">
                                                <v-icon>mdi-information</v-icon>
                                            </v-stepper-step>
                                        </v-stepper-header>
                                    
                                        <v-stepper-items>
                                            <v-stepper-content step="1">
                                            
                                            <v-card flat class="mb-12">
                                                <v-card-text>
                                                    
                                                    <v-row no-gutters >
                                                        <v-col
                                                            cols="12"
                                                        >
                                                            <v-text-field
                                                                solo
                                                                label="Enter full name"
                                                                clearable
                                                                dense
                                                            ></v-text-field>
                                                        </v-col>
                                                    </v-row>

                                                    <v-row no-gutters >
                                                        <v-col
                                                            cols="12"
                                                        >
                                                            <v-text-field
                                                                solo
                                                                label="Enter User name"
                                                                clearable
                                                                dense
                                                            ></v-text-field>
                                                        </v-col>
                                                    </v-row>

                                                    <v-row no-gutters
                                                    >
                                                        <v-col
                                                            cols="12"
                                                        >
                                                            <v-select
                                                                :items="
                                                                    gender
                                                                "
                                                                label="Gender"
                                                                solo
                                                                dense
                                                            ></v-select>
                                                        </v-col>
                                                    </v-row>

                                                    <v-row no-gutters
                                                    >
                                                        <v-col
                                                            cols="12"
                                                        >
                                                            <v-text-field
                                                                solo
                                                                label="Enter NIC number"
                                                                clearable
                                                                dense
                                                            ></v-text-field>
                                                        </v-col>
                                                    </v-row>

                                                    <v-row no-gutters
                                                    >
                                                        <v-col
                                                            cols="12"
                                                        >
                                                        <v-file-input
                                                            label="Upload Image"
                                                            prepend-inner-icon="mdi-camera"
                                                            solo
                                                            dense
                                                            prepend-icon=""
                                                        ></v-file-input>
                                                        </v-col>
                                                    </v-row>
                                                                
                                                </v-card-text>

                                                <v-card-actions>
                                                <v-spacer></v-spacer>
                                                
                                                <v-btn
                                                    depressed
                                                    color="#CBAB04"
                                                    @click="e1 = 2"
                                                    dense
                                                    small
                                                    dark
                                                >
                                                    Next
                                                </v-btn>
                                                </v-card-actions>
                                                
                                            </v-card>
                                    
                                            
                                            
                                            </v-stepper-content>
                                    
                                            <v-stepper-content step="2">
                                                <v-card flat class="mb-12">
                                                    <v-card-text>
                                                    <v-row
                                                        justify="space-around"
                                                        no-gutters
                                                    >
                                                        <v-col
                                                            cols="12"
                                                        >
                                                            <v-text-field
                                                                solo
                                                                label="Phone number"
                                                                clearable
                                                                dense
                                                            ></v-text-field>
                                                        </v-col>
                                                    </v-row>

                                                    <v-row
                                                        justify="space-around"
                                                        no-gutters
                                                    >
                                                        <v-col
                                                            cols="12"
                                                        >
                                                            <v-text-field
                                                                solo
                                                                label="Other phone number"
                                                                clearable
                                                                dense
                                                            ></v-text-field>
                                                        </v-col>
                                                    </v-row>

                                                    <v-row
                                                        justify="space-around"
                                                        no-gutters
                                                    >
                                                        <v-col
                                                            cols="12"
                                                        >
                                                            <v-text-field
                                                                solo
                                                                label="Enter e-mail"
                                                                clearable
                                                                dense
                                                            ></v-text-field>
                                                        </v-col>
                                                    </v-row>

                                                    <v-row
                                                        justify="space-around"
                                                        no-gutters
                                                    >
                                                        <v-col
                                                            cols="12"
                                                        >
                                                            <v-text-field
                                                                solo
                                                                label="Enter address"
                                                                clearable
                                                                dense
                                                            ></v-text-field>
                                                        </v-col>
                                                    </v-row>

                                                    <v-row
                                                        justify="space-around"
                                                        no-gutters
                                                    >
                                                        <v-col
                                                            cols="12"
                                                        >
                                                            <v-text-field
                                                                solo
                                                                label="City"
                                                                clearable
                                                                dense
                                                            ></v-text-field>
                                                        </v-col>
                                                    </v-row>

                                                    <v-row
                                                        justify="space-around"
                                                        no-gutters
                                                    >
                                                        <v-col
                                                            cols="12"
                                                        >
                                                            <v-text-field
                                                                solo
                                                                label="Street"
                                                                clearable
                                                                dense
                                                            ></v-text-field>
                                                        </v-col>
                                                    </v-row>

                                                    <v-row
                                                        justify="space-around"
                                                        no-gutters
                                                    >
                                                        <v-col
                                                            cols="12"
                                                        >
                                                            <v-text-field
                                                                :append-icon="
                                                                    show1
                                                                        ? 'mdi-eye'
                                                                        : 'mdi-eye-off'
                                                                "
                                                                
                                                                label="Enter password"
                                                                name="input-10-1"
                                                                hint="At least 8 characters"
                                                                counter
                                                                solo
                                                                dense
                                                                
                                                            ></v-text-field>
                                                        </v-col>
                                                    </v-row>

                                                    </v-card-text>

                                                    <v-card-actions dense>
                                                        <v-spacer></v-spacer>
                                                        <v-btn
                                                        depressed
                                                        color="#CBAB04"
                                                        @click="e1 = 1"
                                                        dense
                                                        small
                                                        dark
                                                        text
                                                        >
                                                            Back
                                                        </v-btn>

                                                        <v-btn
                                                        depressed
                                                        color="#CBAB04"
                                                        @click="e1 = 3"
                                                        dense 
                                                        small
                                                        dark
                                                        >
                                                            Next
                                                        </v-btn>
                                                    </v-card-actions>

                                                </v-card>

                                                    
                                            
                                            </v-stepper-content>
                                    
                                            <v-stepper-content step="3">
                                                <v-card flat class="mb-12">
                                                                <v-card-text>
                                                            
                                                                <v-row
                                                                    justify="space-around"
                                                                    no-gutters
                                                                >
                                                                    <v-col
                                                                        cols="12"
                                                                    >
                                                                        <v-autocomplete
                                                                            v-model="
                                                                                service
                                                                            "
                                                                            :disabled="
                                                                                isUpdating
                                                                            "
                                                                            :items="
                                                                                svs
                                                                            "
                                                                            solo
                                                                            chips
                                                                            label="Select provided services"
                                                                            dense
                                                                            item-text="name"
                                                                            item-value="name"
                                                                            multiple
                                                                        >
                                                                            <template
                                                                                v-slot:selection="data"
                                                                            >
                                                                                <v-chip
                                                                                    v-bind="
                                                                                        data.attrs
                                                                                    "
                                                                                    :input-value="
                                                                                        data.selected
                                                                                    "
                                                                                    close
                                                                                    @click="
                                                                                        data.select
                                                                                    "
                                                                                    @click:close="
                                                                                        remove(
                                                                                            data.item
                                                                                        )
                                                                                    "
                                                                                >
                                                                                    <v-avatar
                                                                                        left
                                                                                    >
                                                                                        <v-img
                                                                                            :src="
                                                                                                data
                                                                                                    .item
                                                                                                    .avatar
                                                                                            "
                                                                                        ></v-img>
                                                                                    </v-avatar>
                                                                                    {{
                                                                                        data
                                                                                            .item
                                                                                            .name
                                                                                    }}
                                                                                </v-chip>
                                                                            </template>
                                                                            <template
                                                                                v-slot:item="data"
                                                                            >
                                                                                <template
                                                                                    v-if="
                                                                                        typeof data.item !==
                                                                                        'object'
                                                                                    "
                                                                                >
                                                                                    <v-list-item-content
                                                                                        v-text="
                                                                                            data.item
                                                                                        "
                                                                                    ></v-list-item-content>
                                                                                </template>
                                                                                <template
                                                                                    v-else
                                                                                >
                                                                                    <v-list-item-content>
                                                                                        <v-list-item-title
                                                                                            v-html="
                                                                                                data
                                                                                                    .item
                                                                                                    .name
                                                                                            "
                                                                                        ></v-list-item-title>
                                                                                        <v-list-item-subtitle
                                                                                            v-html="
                                                                                                data
                                                                                                    .item
                                                                                                    .group
                                                                                            "
                                                                                        ></v-list-item-subtitle>
                                                                                    </v-list-item-content>
                                                                                </template>
                                                                            </template>
                                                                        </v-autocomplete>
                                                                    </v-col>
                                                                </v-row>

                                                                <v-row
                                                                    justify="space-around"
                                                                    no-gutters
                                                                >
                                                                    <v-col
                                                                        cols="12"
                                                                    >
                                                                        <v-select
                                                                            :items="
                                                                                experience
                                                                            "
                                                                            label="Select experience"
                                                                            solo
                                                                            dense
                                                                        ></v-select>
                                                                    </v-col>
                                                                </v-row>

                                                                <v-row
                                                                    justify="space-around"
                                                                    no-gutters
                                                                >
                                                                    <v-col
                                                                        cols="12"
                                                                    >
                                                                        <v-combobox
                                                                            v-model="
                                                                                select
                                                                            "
                                                                            :items="
                                                                                days
                                                                            "
                                                                            label="Select working days"
                                                                            multiple
                                                                            chips
                                                                            solo
                                                                            dense
                                                                        >
                                                                            <template
                                                                                v-slot:selection="data"
                                                                            >
                                                                                <v-chip
                                                                                    :key="
                                                                                        JSON.stringify(
                                                                                            data.item
                                                                                        )
                                                                                    "
                                                                                    v-bind="
                                                                                        data.attrs
                                                                                    "
                                                                                    :input-value="
                                                                                        data.selected
                                                                                    "
                                                                                    :disabled="
                                                                                        data.disabled
                                                                                    "
                                                                                    @click:close="
                                                                                        data.parent.selectItem(
                                                                                            data.item
                                                                                        )
                                                                                    "
                                                                                >
                                                                                    <v-avatar
                                                                                        class="accent white--text"
                                                                                        left
                                                                                        v-text="
                                                                                            data.item
                                                                                                .slice(
                                                                                                    0,
                                                                                                    1
                                                                                                )
                                                                                                .toUpperCase()
                                                                                        "
                                                                                    ></v-avatar>
                                                                                    {{
                                                                                        data.item
                                                                                    }}
                                                                                </v-chip>
                                                                            </template>
                                                                        </v-combobox>
                                                                    </v-col>
                                                                </v-row>

                                                                <v-row
                                                                    justify="space-around"
                                                                    no-gutters
                                                                >
                                                                    <v-col
                                                                        cols="12"
                                                                    >
                                                                        <v-menu
                                                                            ref="menu"
                                                                            v-model="
                                                                                menu2
                                                                            "
                                                                            :close-on-content-click="
                                                                                false
                                                                            "
                                                                            :nudge-right="
                                                                                40
                                                                            "
                                                                            :return-value.sync="
                                                                                time2
                                                                            "
                                                                            transition="scale-transition"
                                                                            offset-y
                                                                            max-width="290px"
                                                                            min-width="290px"
                                                                        >
                                                                            <template
                                                                                v-slot:activator="{
                                                                                    on,
                                                                                    attrs,
                                                                                }"
                                                                            >
                                                                                <v-text-field
                                                                                    v-model="
                                                                                        time2
                                                                                    "
                                                                                    solo
                                                                                    label="Start time"
                                                                                    dense
                                                                                    prepend-inner-icon="mdi-clock-time-four-outline"
                                                                                    prepend-icon=""
                                                                                    readonly
                                                                                    v-bind="
                                                                                        attrs
                                                                                    "
                                                                                    v-on="
                                                                                        on
                                                                                    "
                                                                                ></v-text-field>
                                                                            </template>
                                                                            <v-time-picker
                                                                                v-if="
                                                                                    menu2
                                                                                "
                                                                                v-model="
                                                                                    time2
                                                                                "
                                                                                full-width
                                                                                @click:minute="
                                                                                    $refs.menu.save(
                                                                                        time2
                                                                                    )
                                                                                "
                                                                            ></v-time-picker>
                                                                        </v-menu>
                                                                    </v-col>
                                                                </v-row>

                                                                <v-row
                                                                    justify="space-around"
                                                                    no-gutters
                                                                >
                                                                    <v-col
                                                                        cols="12"
                                                                    >
                                                                        <v-menu
                                                                            ref="menu"
                                                                            v-model="
                                                                                menu3
                                                                            "
                                                                            :close-on-content-click="
                                                                                false
                                                                            "
                                                                            :nudge-right="
                                                                                40
                                                                            "
                                                                            :return-value.sync="
                                                                                time3
                                                                            "
                                                                            transition="scale-transition"
                                                                            offset-y
                                                                            max-width="290px"
                                                                            min-width="290px"
                                                                        >
                                                                            <template
                                                                                v-slot:activator="{
                                                                                    on,
                                                                                    attrs,
                                                                                }"
                                                                            >
                                                                                <v-text-field
                                                                                    v-model="
                                                                                        time3
                                                                                    "
                                                                                    solo
                                                                                    dense
                                                                                    label="End time"
                                                                                    prepend-inner-icon="mdi-clock-time-four-outline"
                                                                                    prepend-icon=""
                                                                                    readonly
                                                                                    v-bind="
                                                                                        attrs
                                                                                    "
                                                                                    v-on="
                                                                                        on
                                                                                    "
                                                                                ></v-text-field>
                                                                            </template>
                                                                            <v-time-picker
                                                                                v-if="
                                                                                    menu3
                                                                                "
                                                                                v-model="
                                                                                    time3
                                                                                "
                                                                                full-width
                                                                                @click:minute="
                                                                                    $refs.menu.save(
                                                                                        time3
                                                                                    )
                                                                                "
                                                                            ></v-time-picker>
                                                                        </v-menu>
                                                                    </v-col>
                                                                </v-row>

                                                                <v-row
                                                                    justify="space-around"
                                                                    no-gutters
                                                                >
                                                                    <v-col
                                                                        cols="12"
                                                                    >
                                                                        <v-textarea
                                                                            solo
                                                                            dense
                                                                            name="input-7-4"
                                                                            label="Describe qualifications"
                                                                        >
                                                                        </v-textarea>
                                                                    </v-col>
                                                                </v-row>

                                                            </v-card-text>

                                                            <v-card-actions dense>
                                                            <v-spacer></v-spacer>
                                                            <v-btn
                                                            depressed
                                                            color="#CBAB04"
                                                            @click="e1 = 2"
                                                            dense
                                                            small
                                                            dark
                                                            text
                                                            >
                                                                Back
                                                            </v-btn>

                                                            <v-btn
                                                            depressed
                                                            color="#CBAB04"
                                                            @click=" dialog = false "
                                                            dense
                                                            small
                                                            dark
                                                            >
                                                            Save
                                                            </v-btn>
                                                        </v-card-actions>

                                                            </v-card>
                                    
                                            
                                            </v-stepper-content>
                                        </v-stepper-items>
                                        </v-stepper>
                                        </v-col>
                                        
                                        <v-col cols="8">
                                            <v-col cols="12" class="mt-3 mx-auto rounded- align-center text-center"  >
                                                <v-img src="/images/map.jpg" ></v-img>
                                            </v-col>
                                        </v-col>

                                        </v-row>
                                </v-card>

                            </v-dialog>
                            </v-col>
                        </v-row>

                        <v-col
                            cols="12"
                            class="mt-3 mx-auto rounded- align-center text-center"
                        >
                            <v-data-table
                                :headers="headers"
                                :items="contractors"
                                :search="search"
                                :items-per-page="10"
                                dense
                                class="elevation-1"
                            >
                        
                            <template v-slot:item.service="{ item }">
                                <v-dialog
                                    v-model="dialogs"
                                    width="500"
                                    >
                                    <template v-slot:activator="{ on, attrs }">
                                        <v-btn
                                        class="mx-2"
                                        small
                                        text
                                        icon
                                        dense
                                        color="#CBAB04"
                                        v-bind="attrs"
                                        v-on="on"
                                        
                                        >
                                        <v-icon dark>
                                            mdi-information-variant
                                        </v-icon>
                                        </v-btn>
                                    </template>

                                    <v-card>
                                        <v-card-title>
                                            <span class="text-h5">Service details</span>
                                        </v-card-title>
                                        <v-card-text>
                                        aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
                                        </v-card-text>

                                        <v-card-actions>
                                            <v-spacer></v-spacer>
                                            <v-btn
                                                color="#CBAB04"
                                                dense
                                                small
                                                dark
                                                v-bind="attrs"
                                                v-on="on"
                                                @click="dialogs = false"
                                                text
                                            >
                                                Close
                                            </v-btn>

                                            <v-btn
                                                color="#CBAB04"
                                                dense
                                                small
                                                dark
                                                v-bind="attrs"
                                                v-on="on"
                                                @click="dialogs = false"
                                            >
                                                Save
                                            </v-btn>

                                            </v-card-actions>

                                    
                                    </v-card>
                                </v-dialog>
                            </template>

                            <template v-slot:item.actions="{ item }">
                            
                                <v-btn
                                                                                
                                    class="black--text "
                                    @click="editContractor(item)"
                                    color="#CBAB04"
                                    dark
                                    x-small
                                    dense
                                ><v-icon x-small dense class="white--text">
                                    mdi-pencil </v-icon> <strong>&nbsp;info</strong>
                                    
                                </v-btn>
                                <!-- <v-icon
                                small
                                class="mr-2"
                                @click=
                                color="#3F51B5"
                            >
                                mdi-pencil
                            </v-icon> -->
                            <!-- <v-icon
                                small
                                color="error"
                                @click="deleteItem(item)"
                            >   
                                mdi-delete
                            </v-icon> -->

                            <!-- <v-dialog v-model="dialogDelete" max-width="500px">
                                <v-card>
                                    <v-card-title class="text-h5">Are you sure you want to delete this item?</v-card-title>
                                    <v-card-actions>
                                    <v-spacer></v-spacer>
                                    <v-btn color="blue darken-1" text @click="closeDelete">Cancel</v-btn>
                                    <v-btn color="blue darken-1" text @click="deleteItemConfirm">OK</v-btn>
                                    <v-spacer></v-spacer>
                                    </v-card-actions>
                                </v-card>
                            </v-dialog> -->

                            </template>

                            <template v-slot:item.rating="{ item }">
                                <v-rating
                                    v-model="rating"
                                    color="#CBAB04"
                                    background-color="#424242"
                                    empty-icon="$ratingFull"
                                    half-increments
                                    hover
                                    x-small
                                    dense
                                    ></v-rating>
                            </template>

                        </v-data-table>

                        <template>
                            <v-row justify="center">
                                <v-dialog
                                v-model="editdialog"
                                fullscreen
                                hide-overlay
                                transition="dialog-bottom-transition"
                                >
                                <template v-slot:activator="{ on, attrs }">
                                    
                                    
                                    
                                </template>
                                <v-card>
                                    <v-row no-gutters>
                                        <v-toolbar
                                        color="#CBAB04" dense height="36%" dark
                                        >
                                        <v-btn
                                            icon
                                            color="black"
                                            @click="editdialog = false"
                                        >
                                            <strong><v-icon bold>mdi-close</v-icon></strong>
                                        </v-btn>
                                        <v-toolbar-title class="headline" style="margin-right: 30px">
                                            <span class="font-weight-bold text--sm black--text">Contractor - @userName</span>
                                        </v-toolbar-title>
                                        <v-spacer></v-spacer>
                                        <v-toolbar-items>
                                            

                                            <v-btn
                                            
                                            text
                                            @click="deleteItem(item)"
                                            color="black"
                                            >
                                            Delete
                                            </v-btn>
                                            <v-dialog v-model="dialogDelete" max-width="500px">
                                                <v-card>
                                                    <v-card-title class="text-h5">Are you sure you want to delete this contractor?</v-card-title>
                                                    <v-card-actions>
                                                    <v-spacer></v-spacer>
                                                    <v-btn color="#CBAB04"
                                                    dense
                                                    small
                                                    dark text @click="closeDelete">Delete</v-btn>
                                                    <v-btn color="#CBAB04"
                                                    dense
                                                    small
                                                    dark @click="deleteItemConfirm">Cancel</v-btn>
                                                    <v-spacer></v-spacer>
                                                    </v-card-actions>
                                                </v-card>
                                            </v-dialog>

                                            <v-btn
                                            
                                            text
                                            @click="editdialog = false"
                                            color="black"
                                            >
                                            Save
                                            </v-btn>
                                            
                                        </v-toolbar-items>
                                        </v-toolbar>
                                    </v-row>

                                    <v-card class="mx-auto">
                                        <v-row no-gutters>
                                            <v-col cols="6" dense>

                                                    <v-card class="mx-auto">
                                                        <v-row justify="center" class="spacer" align="center" no-gutters>
                                                                <v-col cols="4">
                                                                    <v-row justify="center">
                                                                    <image-input
                                                                        v-model="
                                                                            avatar
                                                                        "
                                                                        
                                                                    >
                                                                        <div
                                                                            slot="activator"
                                                                        >
                                                                            <v-avatar
                                                                                size="200px"
                                                                                v-ripple
                                                                                v-if="
                                                                                    !avatar
                                                                                "
                                                                                
                                                                                class="grey lighten-3 mb-3 mx-auto rounded- align-center text-center"
                                                                            >
                                                                                <span
                                                                                    >Click
                                                                                    to
                                                                                    add
                                                                                    image</span
                                                                                >
                                                                            </v-avatar>
                                                                            <v-avatar
                                                                                size="150px"
                                                                                v-ripple
                                                                                v-else
                                                                                class="mb-3"
                                                                            >
                                                                                <img
                                                                                    :src="
                                                                                        avatar.imageURL
                                                                                    "
                                                                                    alt="avatar"
                                                                                />
                                                                            </v-avatar>
                                                                        </div>
                                                                    </image-input>
                                                                

                                                                    <v-rating
                                                                        v-model="rating"
                                                                        color="#CBAB04"
                                                                        background-color="#424242"                                                                    
                                                                        half-increments
                                                                        hover
                                                                        medium
                                                                        dense 
                                                                    ></v-rating>
                                                                </v-row>
                                                                </v-col>

                                                                <v-col cols="4">
                                                                    <v-card-text>
                                                                        <v-text-field
                                                                            placeholder="Dense & Rounded"
                                                                            filled
                                                                            rounded
                                                                            dense
                                                                            v-model="form.name"
                                                                            label="Name:"></v-text-field>

                                                                        <v-text-field
                                                                            placeholder="Dense & Rounded"
                                                                            filled
                                                                            rounded
                                                                            dense
                                                                            v-model="form.address"
                                                                            label="Address: "></v-text-field>

                                                                        <v-text-field
                                                                            placeholder="Dense & Rounded"
                                                                            filled
                                                                            rounded
                                                                            dense
                                                                            v-model="form.qualification"
                                                                            label="Qualification: "></v-text-field>
                                                                    </v-card-text>
                                                                </v-col>

                                                                <v-col cols="4">
                                                                    <v-card-text>
                                                                        <v-text-field
                                                                            placeholder="Dense & Rounded"
                                                                            filled
                                                                            rounded
                                                                            dense
                                                                            v-model="form.email"
                                                                            label="Email: "></v-text-field>

                                                                        <v-text-field
                                                                            placeholder="Dense & Rounded"
                                                                            filled
                                                                            rounded
                                                                            dense
                                                                            v-model="form.contactNo"
                                                                            label="Mobile no.: "></v-text-field>

                                                                        <v-text-field
                                                                            placeholder="Dense & Rounded"
                                                                            filled
                                                                            rounded
                                                                            dense
                                                                            v-model="form.experience"
                                                                            label="Experience: "></v-text-field> 
                                                                    </v-card-text>
                                                                </v-col>
                                                        </v-row>
                                                    </v-card>

                                                    <v-card class="mx-auto">
                                                        <v-col cols="12" md="8" class="mt-3 mx-auto rounded- align-center text-center" >
                                                            <v-text-field
                                                                v-model="search"
                                                                append-icon="mdi-magnify"
                                                                label="Search services"
                                                                single-line
                                                                hide-details
                                                            ></v-text-field>
                                                        </v-col>

                                                        <v-row justify="space-around" >
                                                                <v-col cols="12" class="mt-3 mx-auto rounded- align-center text-center">
                                                                    <v-card>
                                                                        <v-data-table
                                                                            :headers="headerssm"
                                                                            :search="search"
                                                                            :items-per-page="5"
                                                                            :items="servicehistory"
                                                                            dense
                                                                            class="elevation-1"
                                                                            >

                                                                            <template v-slot:item.infosh="{ item }">
                                                                                    
                                                                            <v-dialog
                                                                            v-model="dialogsh"
                                                                            width="600px"
                                                                            >
                                                                            <template v-slot:activator="{ on, attrs }">
                                                                                
                                                                                <v-btn
                                                                                    class="mr-2 black--text"
                                                                                    @click="dialogsh(item)"
                                                                                    color="#CBAB04"
                                                                                    v-bind="attrs"
                                                                                    v-on="on"
                                                                                    dense                                                                                dark
                                                                                    x-small
                                                                                ><v-icon dense class="white--text">
                                                                                    mdi-information-variant </v-icon> 
                                                                                    <strong>&nbsp; view</strong>
                                                                                </v-btn>
                                                                                
                                                                            </template>
                                                                            <v-card>
                                                                                <v-card-title>
                                                                                <span class="text-h5">Service-@ details</span>
                                                                                </v-card-title>
                                                                                <v-card-text>
                                                                                Lorem ipsum dolor sit amet, semper quis, sapien id natoque elit. Nostra urna at, magna at neque sed sed ante imperdiet, dolor mauris cursus velit, velit non, sem nec. Volutpat sem ridiculus placerat leo, augue in, duis erat proin condimentum in a eget, sed fermentum sed vestibulum varius ac, vestibulum volutpat orci ut elit eget tortor. Ultrices nascetur nulla gravida ante arcu. Pharetra rhoncus morbi ipsum, nunc tempor debitis, ipsum pellentesque, vitae id quam ut mauris dui tempor, aptent non. Quisque turpis. Phasellus quis lectus luctus orci eget rhoncus. Amet donec vestibulum mattis commodo, nulla aliquet, nibh praesent, elementum nulla. Sit lacus pharetra tempus magna neque pellentesque, nulla vel erat.
                                                                                Justo ex quisque nulla accusamus venenatis, sed quis. Nibh phasellus gravida metus in, fusce aenean ut erat commodo eros. Ut turpis, dui integer, nonummy pede placeat nec in sit leo. Faucibus porttitor illo taciti odio, amet viverra scelerisque quis quis et tortor, curabitur morbi a. Enim tempor at, rutrum elit condimentum, amet rutrum vitae tempor torquent nunc. Praesent vestibulum integer maxime felis. Neque aenean quia vitae nostra, tempus elit enim id dui, at egestas pulvinar. Integer libero vestibulum, quis blandit scelerisque mattis fermentum nulla, tortor donec vestibulum dolor amet eget, elit nullam. Aliquam leo phasellus aliquam curabitur metus a, nulla justo mattis duis interdum vel, mollis vitae et id, vestibulum erat ridiculus sit pulvinar justo sed. Vehicula convallis, et nulla wisi, amet vestibulum risus, quam ac egestas.
                                                                                
                                                                                </v-card-text>
                                                                                <v-card-actions>
                                                                                <v-spacer></v-spacer>
                                                                                <v-btn
                                                                                    color="#CBAB04"
                                                                                    class="mr-2"
                                                                                    @click="dialogsh = false"
                                                                                    dark
                                                                                    x-small
                                                                                    dense
                                                                                    
                                                                                >
                                                                                    Close
                                                                                </v-btn>
                                                                                <!-- <v-btn
                                                                                    color="green darken-1"
                                                                                    text
                                                                                    @click="dialogsh = false"
                                                                                >
                                                                                    Agree
                                                                                </v-btn> -->
                                                                                </v-card-actions>
                                                                            </v-card>
                                                                            </v-dialog>
                                                                            </template>

                                                                            <template v-slot:item.customer="{ item }">
                                                                                
                                                                                <v-dialog
                                                                                v-model="dialogc"
                                                                                width="600px"
                                                                                >
                                                                                <template v-slot:activator="{ on, attrs }">
                                                                                    
                                                                                    <v-icon
                                                                                    
                                                                                    class="mr-2"
                                                                                    @click="dialogc(item)"
                                                                                    color="#CBAB04"
                                                                                    v-bind="attrs"
                                                                                    v-on="on"
                                                                                    fab
                                                                                    dark
                                                                                >
                                                                                mdi-account-details
                                                                                </v-icon>
                                                                                    
                                                                                </template>
                                                                                    <v-card>
                                                                                        <v-card-title>
                                                                                            <span class="text-h5">Customer details</span>
                                                                                        </v-card-title>
                                                                                        
                                                                                        <v-card-text>
                                                                                        Lorem ipsum dolor sit amet, semper quis, sapien id natoque elit. Nostra urna at, magna at neque sed sed ante imperdiet, dolor mauris cursus velit, velit non, sem nec. Volutpat sem ridiculus placerat leo, augue in, duis erat proin condimentum in a eget, sed fermentum sed vestibulum varius ac, vestibulum volutpat orci ut elit eget tortor. Ultrices nascetur nulla gravida ante arcu. Pharetra rhoncus morbi ipsum, nunc tempor debitis, ipsum pellentesque, vitae id quam ut mauris dui tempor, aptent non. Quisque turpis. Phasellus quis lectus luctus orci eget rhoncus. Amet donec vestibulum mattis commodo, nulla aliquet, nibh praesent, elementum nulla. Sit lacus pharetra tempus magna neque pellentesque, nulla vel erat.
                                                                                        Justo ex quisque nulla accusamus venenatis, sed quis. Nibh phasellus gravida metus in, fusce aenean ut erat commodo eros. Ut turpis, dui integer, nonummy pede placeat nec in sit leo. Faucibus porttitor illo taciti odio, amet viverra scelerisque quis quis et tortor, curabitur morbi a. Enim tempor at, rutrum elit condimentum, amet rutrum vitae tempor torquent nunc. Praesent vestibulum integer maxime felis. Neque aenean quia vitae nostra, tempus elit enim id dui, at egestas pulvinar. Integer libero vestibulum, quis blandit scelerisque mattis fermentum nulla, tortor donec vestibulum dolor amet eget, elit nullam. Aliquam leo phasellus aliquam curabitur metus a, nulla justo mattis duis interdum vel, mollis vitae et id, vestibulum erat ridiculus sit pulvinar justo sed. Vehicula convallis, et nulla wisi, amet vestibulum risus, quam ac egestas.
                                                                                        
                                                                                        </v-card-text>
                                                                                        
                                                                                        <v-card-actions>
                                                                                        <v-spacer></v-spacer>
                                                                                        <v-btn
                                                                                            color="#CBAB04"
                                                                                            dark
                                                                                            x-small
                                                                                            dense
                                                                                            @click="dialogc = false"
                                                                                            class="mr-2"
                                                                                            text
                                                                                        >
                                                                                            Close
                                                                                        </v-btn>

                                                                                        <v-btn
                                                                                            color="#CBAB04"
                                                                                            dark
                                                                                            x-small
                                                                                            dense
                                                                                            @click="dialogc = false"
                                                                                            class="mr-2"
                                                                                        >
                                                                                            Save
                                                                                        </v-btn>

                                                                                        </v-card-actions>
                                                                                    </v-card>
                                                                                </v-dialog>
                                                                                
                                                                            </template>

                                                                            <template v-slot:item.ratingsh="{ item }">
                                                                                
                                                                                <v-dialog
                                                                                v-model="dialogr"
                                                                                width="600px"
                                                                                >
                                                                                <template v-slot:activator="{ on, attrs }">
                                                                                    
                                                                                    <v-rating
                                                                                    v-model="ratingsh"
                                                                                    color="#CBAB04"
                                                                                    background-color="grey darken-1"
                                                                                    empty-icon="$ratingFull"
                                                                                    half-increments
                                                                                    hover
                                                                                    x-small
                                                                                    dense
                                                                                    ></v-rating>
                                                                                    
                                                                                </template>
                                                                                </v-dialog>
                                                                            </template>

                                                                        </v-data-table>
                                                                    </v-card>
                                                                </v-col>
                                                        </v-row>
                                                    </v-card>
                                                
                                            </v-col>

                                            <v-col cols="6">
                                                            <v-img
                                                                src="/images/map.jpg"
                                                            ></v-img>

                                            </v-col>
                                        </v-row>
                                    </v-card>

                                </v-card>
                                </v-dialog>
                            </v-row>
                            </template>
                            
                            <!-- <template v-slot:no-data>
                            <v-btn
                                color="primary"
                                @click="initialize"
                            >
                                Reset
                            </v-btn>
                            </template> -->
                            
                        </v-col>

                        </v-col>
                        </v-row>
                    <!-- </v-responsive> -->
                
                    </v-col>

            <v-col cols="12" md="7">
                
                    <v-col
                        cols="12"
                        class="mt-3 mx-auto rounded- align-center text-center"
                    >
                        <v-col
                            cols="8"
                            class="mt-3 mx-auto rounded- align-center text-center"
                        >
                            <v-btn
                                :loading="loading"
                                :disabled="loading"
                                color="#424242"
                                class="white--text"
                                @click="loader = 'loading'"
                                large
                            >
                                Draw proximity
                                <template v-slot:loader>
                                    <span class="custom-loader">
                                        <v-icon light>mdi-cached</v-icon>
                                    </span>
                                </template>
                            </v-btn>
                        </v-col>

                        <v-img src="/images/map.jpg"></v-img>
                    </v-col>
                
            </v-col>
        </v-row>
    </v-card>
</template>

<script>

export default {
    data: () => ({
        dialog: false,
        dialogsh: false,
        dialogc: false,
        dialogr: false,
        dialogs: false,
        infosh: false,
        editdialog: false,
        avatar: false,
        radios: null,
        attrs:false,
        on:false,
        e1: 1,
        checkbox: false,
        tab: null,
        select: [],
        items: [],
        phone: [0],
        rating: 4.5,
        ratingsh: 3,
        

        dialogDelete: false,
        search: "",
        role: ["Agent", "Contractor", "Charted Engineer"],
        gender: ["Male", "Female"],
        show1: false,
        rules: {
            required: (value) => !!value || "Required.",
            min: (v) => v.length >= 8 || "Min 8 characters",
        },
        service: [],
        svs: [
            { header: "Group 1" },
            { name: "Service 1", group: "Group 1" },
            { name: "Service 2", group: "Group 1" },
            { name: "Service 3", group: "Group 1" },
            { name: "Service 4", group: "Group 1" },
            { divider: true },
            { header: "Group 2" },
            { name: "Service 5", group: "Group 2" },
            { name: "Service 6", group: "Group 2" },
            { name: "Service 7", group: "Group 2" },
            { name: "Service 8", group: "Group 2" },
            { divider: true },
            { header: "Group 3" },
            { name: "Service 9", group: "Group 3" },
            { name: "Service 10", group: "Group 3" },
            { name: "Service 11", group: "Group 3" },
            { name: "Service 12", group: "Group 3" },
        ],
        experience: [
            "1 - 12 Months",
            "1 - 2 Years",
            "2 - 3 Years",
            "3 - 4 Years",
            "4 - 5 Years",
            "Above 5 years",
        ],
        days: [
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday",
            "Saturday",
            "Sunday",
        ],

        time2: null,
        time3: null,
        menu2: false,
        menu3: false,

        autoUpdate: true,
        isUpdating: false,

        loader: null,
        loading: false,

        watch: {
            isUpdating(val) {
                if (val) {
                    setTimeout(() => (this.isUpdating = false), 3000);
                }
            },
            loader() {
                const l = this.loader;
                this[l] = !this[l];

                setTimeout(() => (this[l] = false), 3000);

                this.loader = null;
            },
            dialog (val) {
                val || this.close()
            },
            dialogDelete (val) {
                val || this.closeDelete()
            },
        },

        headers: [
          {
          text: 'Contractor',
          align: 'start',
          sortable: false,
          value: 'name'
          },
          { text: 'Contact No', value: 'phone', sortable: false },
          { text: 'Rating', value: 'rating', sortable: false },
          { text: 'Services', value: 'service', sortable: false },
          { text: 'View Contractor', value: 'actions', sortable: false },
        ],

        headerssm:[
          {text: 'Service Id',
          align: 'start',
          sortable: false,
          value: 'id'
          },
          { text: 'Customer', value: 'customer', sortable: false },
          { text: 'Date', value: 'datesh' , sortable: false},
          { text: 'Rating', value: 'ratingsh', sortable: false },
          { text: 'More details', value: 'infosh', sortable: false },],


            editedItem: {
                id: '0',
            datesh: '',

            },
            defaultItem: {
                id: '0',
            datesh: '',
            },

            contractors: [],
        editedIndex: -1,

        editedItem: {
            name: '',
            phone: '', 
            rating: '',
        
        },
        defaultItem: {
            name: '',
            phone: '',
            rating: '',
        },

        form: {
                    name: 'CelaTa Leco',
                    email: 'celata@leco.com',
                    contactNo: '0711111111 / 0772222222',
                    address: '23/B, Celata, Leco',
                    qualification: 'BSc (Hons) Leco Celata',
                    experience: '4 years',

                },
    }),

    computed: {
      formTitle () {
        return this.editedIndex === -1 ? 'Add Contractor' : 'Edit Item'
      },
    },

    created () {
      this.initialize()
    },

    methods: {
      initialize () {
        this.contractors = [
          {
            name: 'CelaTa Leco',
            phone: '0711111111-0772222222',
            
          },
          {
            name: 'Dasun Shanaka',
            phone: '0711234567-0118976347',
            
          },
          {
            name: 'Savin Sathsara',
            phone: '0475656432-0112346783',
            
          },
          {
            name: 'Virat Kohli',
            phone: '0765445678-0338765628',
            
          },
          {
            name: 'Kaveen Savindra',
            phone: '0745676589-0774567892',
            
          },
          {
            name: 'Praveena Leo',
            phone: '071126666 ',
            
          },
          {
            name: 'Uvindu Rihan',
            phone: '0786572829-0779876543',
            
          },
          {
            name: 'Indika Bandara',
            phone: '0711234563-0702345678',
            
          },
          {
            name: 'Pahan Ransilu',
            phone: '0775674563-0781234567',
            
            
          },
          {
            name: 'Hiran Kavinga',
            phone: '0704567892-0771234567',
            
            
          },
        ]
        this.servicehistory = [
          {
            id: '111',
            datesh: '10/27/2022',
            
          },

          {
            id: '112',
            datesh: '11/6/2022',
            
          },

          {
            id: '113',
            datesh: '11/8/2022',
            
          },

          {
            id: '114',
            datesh: '11/9/2022',

          },

          {
            id: '115',
            datesh: '11/29/2022',
            
          },

          {
            id: '116',
            datesh: '11/29/2022',
            
          },

          {
            id: '117',
            datesh: '12/2/2022',
            
          },

          {
            id: '118',
            datesh: '12/20/2022',
            
          },

          {
            id: '119',
            datesh: '12/29/2022',
            
          },

          {
            id: '120',
            datesh: '1/2/2023',
            
          },
          

          
        ]
      },

      editItem (item) {
        this.editedIndex = this.contractors.indexOf(item)
        this.editedItem = Object.assign({}, item)
        this.dialog = true
      },

      editContractor (item) {
        this.editedIndex = this.contractors.indexOf(item)
        this.editedItem = Object.assign({}, item)
        this.editdialog = true
      },

      addContractor (item) {
        this.editedIndex = this.contractors.indexOf(item)
        this.editedItem = Object.assign({}, item)
        this.editdialog1 = true
      },

      deleteItem (item) {
        this.editedIndex = this.contractors.indexOf(item)
        this.editedItem = Object.assign({}, item)
        this.dialogDelete = true
      },

      deleteItemConfirm () {
        this.contractors.splice(this.editedIndex, 1)
        this.closeDelete()
      },

      close () {
        this.dialog = false
        this.$nextTick(() => {
          this.editedItem = Object.assign({}, this.defaultItem)
          this.editedIndex = -1
        })
      },

      closeDelete () {
        this.dialogDelete = false
        this.$nextTick(() => {
          this.editedItem = Object.assign({}, this.defaultItem)
          this.editedIndex = -1
        })
      },

      save () {
        if (this.editedIndex > -1) {
          Object.assign(this.contractors[this.editedIndex], this.editedItem)
        } else {
          this.contractors.push(this.editedItem)
        }
        this.close()
      },
    },

};

</script>

<style>
.custom-loader {
    animation: loader 1s infinite;
    display: flex;
}

@-moz-keyframes loader {
    from {
        transform: rotate(0);
    }
    to {
        transform: rotate(360deg);
    }
}
@-webkit-keyframes loader {
    from {
        transform: rotate(0);
    }
    to {
        transform: rotate(360deg);
    }
}
@-o-keyframes loader {
    from {
        transform: rotate(0);
    }
    to {
        transform: rotate(360deg);
    }
}
@keyframes loader {
    from {
        transform: rotate(0);
    }
    to {
        transform: rotate(360deg);
    }
}
</style>
