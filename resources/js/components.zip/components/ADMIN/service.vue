<template>
    <v-card>

        <v-row class="pa-4 pb-0" no-gutters>
            <v-col cols="5">
                <v-responsive class="overflow-y-auto">
                    <v-row class="pa-5">
                        <v-row class="pa-5">
                                

                                <v-col cols="4">
                                    <v-select
                                        v-model="cost"
                                        :items="items"
                                        chips
                                        label="Cost"
                                        multiple
                                        solo
                                        dense

                                    ></v-select>
                                </v-col>

                                <v-col cols="4">
                                    <v-select
                                        v-model="subcategory"
                                        :items="items"
                                        chips
                                        label="Sub catregory"
                                        multiple
                                        dense
                                        solo
                                    ></v-select>
                                </v-col>

                                <v-col cols="3">
                                    <v-btn
                                        :loading="loading"
                                        :disabled="loading"
                                        color="#424242"
                                        class="white--text mt-1"
                                        @click="loader = 'loading'"
                                        dense
                                    >
                                        Filter
                                        <template v-slot:loader>
                                            <span class="custom-loader">
                                                <v-icon light>mdi-cached</v-icon>
                                            </span>
                                        </template>
                                    </v-btn>
                                </v-col>
                        </v-row>

                        <v-row no-gutters>
                            
                            <v-col
                                cols="12" xs="10" sm="10" md="10" lg="10" xl="10"
                                >
                                    <v-text-field
                                        v-model="search"
                                        append-icon="mdi-magnify"
                                        label="Search"
                                        single-line
                                        hide-details
                                        clearable
                                    ></v-text-field>
                                </v-col>
                            
                                <v-col
                                cols="2"
                                class="mt-3 mx-auto rounded- align-center text-center"
                                >
                                <v-dialog v-model="dialog" fullscreen  hide-overlay 
                                    >
                                    <template v-slot:activator="{ on, attrs }">
                                        <v-btn
                                            color="#CBAB04"
                                            v-bind="attrs"
                                            v-on="on"
                                            class="font-weight-bold text--sm white--text"
                                            fab
                                            small
                                            >
                                            <v-icon dark>
                                                mdi-plus
                                            </v-icon>

                                            </v-btn>
                                    </template>

                                    <v-card  flat class="mb-12">

                                        <v-toolbar
                                        dark
                                            color="#CBAB04"  dense height="36%"
                                            >
                                            <v-btn
                                                
                                            icon
                                                color="black"
                                                v-bind="attrs"
                                                        v-on="on"
                                                        @click="dialog = false"
                                                        
                                                        
                                            >
                                                <v-icon>mdi-close</v-icon>
                                            </v-btn>
                                            <v-toolbar-title class="headline" style="margin-right: 30px">
                                                <span class="font-weight-bold text--sm black--text"> Add new Service </span> 
                                            </v-toolbar-title>
                                            <v-spacer></v-spacer>
                                            <v-toolbar-items>
                                                <!-- <v-btn
                                                    dark
                                                    text
                                                    @click="deleteItem(item)"
                                                    
                                                    >
                                                    Delete
                                                    </v-btn>
                                                    <v-dialog v-model="dialogDelete" max-width="500px">
                                                        <v-card>
                                                            <v-card-title class="text-h5">Are you sure you want to delete this Agent?</v-card-title>
                                                            <v-card-actions>
                                                            <v-spacer></v-spacer>
                                                            <v-btn color="blue darken-1" text @click="closeDelete">Cancel</v-btn>
                                                            <v-btn color="blue darken-1" text @click="deleteItemConfirm">OK</v-btn>
                                                            <v-spacer></v-spacer>
                                                            </v-card-actions>
                                                        </v-card>
                                                    </v-dialog> -->

                                            </v-toolbar-items>
                                        </v-toolbar>

                                            <v-row class="pa-4 pb-0">
                                                <v-col cols="3">
                                                    <!-- <v-responsive
                                                        class="overflow-y-auto"
                                                        max-height="661"
                                                    > -->
                                                                                                        
                                                        <v-col
                                                            cols="12"
                                                            md="10"
                                                            class="mt-3 mx-auto rounded- align-center text-center"
                                                            style="background-color: #424242;"
                                                            >
                                                            
                                                                
                                                                <v-container fluid  class="px-4">
                                                                        
                                                                        
                                                                        <v-row
                                                                            justify="space-around"
                                                                            no-gutters
                                                                        >
                                                                            <v-col
                                                                                cols="12"
                                                                            >
                                                                                <v-text-field
                                                                                    solo
                                                                                    label="Service ID"
                                                                                    clearable
                                                                                    dense
                                                                                ></v-text-field>
                                                                            </v-col>
                                                                        </v-row>

                                                                        <v-row
                                                                            justify="space-around"
                                                                            no-gutters
                                                                        >
                                                                            <v-col
                                                                                cols="12"
                                                                            >
                                                                                <v-text-field
                                                                                    solo
                                                                                    label="Service name"
                                                                                    clearable
                                                                                    dense
                                                                                ></v-text-field>
                                                                            </v-col>
                                                                        </v-row>

                                                                        <v-row
                                                                            justify="space-around"
                                                                            no-gutters
                                                                        >
                                                                            <v-col
                                                                                cols="12"
                                                                            >
                                                                                <v-select
                                                                                    :items="
                                                                                        subcategory
                                                                                    "
                                                                                    label="Sub category"
                                                                                    solo
                                                                                    dense
                                                                                ></v-select>
                                                                            </v-col>
                                                                        </v-row>

                                                                        <v-row
                                                                            justify="space-around"
                                                                            no-gutters
                                                                        >
                                                                            <v-col
                                                                                cols="12"
                                                                            >
                                                                                <v-text-field
                                                                                    solo
                                                                                    label="Service cost"
                                                                                    clearable
                                                                                    dense
                                                                                ></v-text-field>
                                                                            </v-col>
                                                                        </v-row>

                                                                        <v-row
                                                                            justify="space-around"
                                                                            no-gutters
                                                                        >
                                                                            <v-col
                                                                                cols="12"
                                                                            >
                                                                                <v-textarea
                                                                                    solo
                                                                                    label="Qualifications"
                                                                                    dense
                                                                                >
                                                                                </v-textarea>
                                                                            </v-col>
                                                                        </v-row>

                                                                        <v-row
                                                                            justify="space-around"
                                                                            no-gutters
                                                                        >
                                                                            <v-col
                                                                                cols="12"
                                                                            >
                                                                                <v-text-field
                                                                                    solo
                                                                                    label="Available contractors"
                                                                                    clearable
                                                                                    dense
                                                                                ></v-text-field>
                                                                            </v-col>
                                                                        </v-row>
                                                                        <v-card-actions dense>
                                                                            <v-spacer></v-spacer>
                                                                            <v-btn
                                                                            depressed
                                                                            color="#CBAB04"
                                                                            dense
                                                                            small
                                                                            dark
                                                                            text
                                                                                @click="
                                                                                    dialog = false
                                                                                "
                                                                            >
                                                                                Close
                                                                            </v-btn>

                                                                            <v-btn
                                                                                depressed
                                                                                color="#CBAB04"
                                                                                dense 
                                                                                small
                                                                                dark
                                                                                @click="
                                                                                    dialog = false
                                                                                "
                                                                            >
                                                                                Save
                                                                            </v-btn>
                                                                        </v-card-actions>

                                                                </v-container>
                                                        
                                                        </v-col>
                                                    <!-- </v-responsive> -->

                                            </v-col>

                                            <v-col cols="9" class="mt-3 mx-auto rounded- align-center text-right">

                                                

                                                <v-col
                                                    cols="12"
                                                    class="mt-3 mx-auto rounded- align-center text-center"
                                                >
                                                    <v-img
                                                        src="/images/map.jpg"
                                                    ></v-img>
                                                </v-col>
                                                        

                                            </v-col>
                                        </v-row>
                                    </v-card>
                                </v-dialog>
                            </v-col>
                        </v-row>    

                        <v-col cols="12" class="mt-3 mx-auto rounded- align-center text-center" >
                            <v-data-table
                            :headers="headers"
                            :search="search"
                            :items-per-page="7"
                            :items="services"
                            class="elevation-1"
                            dense
                            >
                            <template v-slot:item.actions="{ item }">
                                
                                <v-btn
                                                                                    
                                    class="black--text "
                                    @click="editService(item)"
                                    color="#CBAB04"
                                    dark
                                    x-small
                                    dense
                                ><v-icon x-small dense class="white--text">
                                    mdi-pencil </v-icon> <strong>&nbsp;info</strong>
                                    
                                </v-btn>
                                
                                <!-- <v-icon
                                    small
                                    @click="deleteItem(item)"
                                    color="error"
                                >
                                    mdi-delete
                                </v-icon> -->
                            </template>
                                

                                <!-- <v-dialog v-model="dialogDelete" max-width="500px">
                                    <v-card>
                                        <v-card-title class="text-h5">Are you sure you want to delete this item?</v-card-title>
                                        <v-card-actions>
                                        <v-spacer></v-spacer>
                                        <v-btn color="blue darken-1" text @click="closeDelete">Cancel</v-btn>
                                        <v-btn color="blue darken-1" text @click="deleteItemConfirm">OK</v-btn>
                                        <v-spacer></v-spacer>
                                        </v-card-actions>
                                    </v-card>
                                </v-dialog> -->

                                <template v-slot:item.qualification="{ item }">
                                    <v-dialog
                                        v-model="dialogq"
                                        width="500"
                                        >
                                        <template v-slot:activator="{ on, attrs }">
                                            <v-btn
                                            class="mx-2"
                                            small
                                            text
                                            icon
                                            dense
                                            color="#CBAB04"
                                            v-bind="attrs"
                                            v-on="on"
                                            >
                                            <v-icon dark>
                                                mdi-information-variant
                                            </v-icon>
                                            </v-btn>
                                        </template>

                                        <v-card>
                                            
                                            <v-card-title>
                                                <span class="text-h5">Service  details</span>
                                            </v-card-title>
                                            
                                            <v-card-text>
                                            Lorem ipsum dolor sit amet, semper quis, sapien id natoque elit. Nostra urna at, magna at neque sed sed ante imperdiet, dolor mauris cursus velit, velit non, sem nec. Volutpat sem ridiculus placerat leo, augue in, duis erat proin condimentum in a eget, sed fermentum sed vestibulum varius ac, vestibulum volutpat orci ut elit eget tortor. Ultrices nascetur nulla gravida ante arcu. Pharetra rhoncus morbi ipsum, nunc tempor debitis, ipsum pellentesque, vitae id quam ut mauris dui tempor, aptent non. Quisque turpis. Phasellus quis lectus luctus orci eget rhoncus. Amet donec vestibulum mattis commodo, nulla aliquet, nibh praesent, elementum nulla. Sit lacus pharetra tempus magna neque pellentesque, nulla vel erat.
                                            Justo ex quisque nulla accusamus venenatis, sed quis. Nibh phasellus gravida metus in, fusce aenean ut erat commodo eros. Ut turpis, dui integer, nonummy pede placeat nec in sit leo. Faucibus porttitor illo taciti odio, amet viverra scelerisque quis quis et tortor, curabitur morbi a. Enim tempor at, rutrum elit condimentum, amet rutrum vitae tempor torquent nunc. Praesent vestibulum integer maxime felis. Neque aenean quia vitae nostra, tempus elit enim id dui, at egestas pulvinar. Integer libero vestibulum, quis blandit scelerisque mattis fermentum nulla, tortor donec vestibulum dolor amet eget, elit nullam. Aliquam leo phasellus aliquam curabitur metus a, nulla justo mattis duis interdum vel, mollis vitae et id, vestibulum erat ridiculus sit pulvinar justo sed. Vehicula convallis, et nulla wisi, amet vestibulum risus, quam ac egestas.
                                            
                                            </v-card-text>
                                            
                                            <v-card-actions>
                                            <v-spacer></v-spacer>
                                            <v-btn
                                                color="#CBAB04"
                                                dark
                                                x-small
                                                dense
                                                v-bind="attrs"
                                                v-on="on"
                                                @click="dialogq = false"
                                                class="mr-2"
                                                text
                                            >
                                                Close
                                            </v-btn>

                                            <v-btn
                                                color="#CBAB04"
                                                dark
                                                x-small
                                                dense
                                                class="mr-2"
                                                v-bind="attrs"
                                                v-on="on"
                                                @click="dialogq = false"                                           
                                            >
                                                Save
                                            </v-btn>

                                            </v-card-actions>
                                        </v-card>
                                    </v-dialog>
                                </template>

                                <template v-slot:item.subcategory = "{ item }">
                                    <v-chip :color="getColor(item.subcategory)" dark label x-small>
                                        {{ item.subcategory }}
                                    </v-chip>
                                </template>

                        </v-data-table>

                        <template>
                            <v-row justify="center">
                                <v-dialog
                                v-model="editdialog"
                                fullscreen
                                hide-overlay
                                transition="dialog-bottom-transition"
                                >
                                <template v-slot:activator="{ on, attrs }">
                                                    
                                
                                </template>

                                <v-card>
                                    <v-toolbar
                                        color="#CBAB04" dense height="36%" dark
                                        >
                                        <v-btn
                                            
                                            icon
                                            color="black"
                                            v-bind="attrs"
                                            v-on="on"
                                            @click="editdialog = false"
                                                    
                                                    
                                        >
                                            <v-icon>mdi-close</v-icon>
                                        </v-btn>
                                        <v-toolbar-title class="headline" style="margin-right: 30px"><span class="font-weight-bold text--sm black--text">Edit Service - @Service name</span></v-toolbar-title>
                                        <v-spacer></v-spacer>
                                        <!-- <v-toolbar-items>
                                            
                                            <v-btn
                                            color="black"
                                            text
                                            @click="editdialog = false"
                                            >
                                            Save
                                            </v-btn>
                                        </v-toolbar-items> -->
                                    </v-toolbar>

                                    <v-row class="pa-4 pb-0">
                                        <v-col cols="3">
                                        
                                            <!-- <v-responsive
                                                class="overflow-y-auto"
                                                max-height="661"
                                            > -->
                                                                                                    
                                                <v-col
                                                    cols="12"
                                                    md="10"
                                                    class="mt-3 mx-auto rounded- align-center text-center"
                                                    style="background-color: #424242;"
                                                    >
                                                    

                                                            <v-container fluid  class="px-4">
                                                                    
                                                                    
                                                                    <v-row
                                                                        justify="space-around"
                                                                        no-gutters
                                                                    >
                                                                        <v-col
                                                                            cols="12"
                                                                        >
                                                                            <v-text-field
                                                                                solo
                                                                                label="Service ID"
                                                                                clearable
                                                                                dense
                                                                            ></v-text-field>
                                                                        </v-col>
                                                                    </v-row>

                                                                    <v-row
                                                                        justify="space-around"
                                                                        no-gutters
                                                                    >
                                                                        <v-col
                                                                            cols="12"
                                                                        >
                                                                            <v-text-field
                                                                                solo
                                                                                label="Service name"
                                                                                clearable
                                                                                dense
                                                                            ></v-text-field>
                                                                        </v-col>
                                                                    </v-row>

                                                                    <v-row
                                                                        justify="space-around"
                                                                        no-gutters
                                                                    >
                                                                        <v-col
                                                                            cols="12"
                                                                        >
                                                                            <v-select
                                                                                :items="
                                                                                    subcategory
                                                                                "
                                                                                label="Sub category"
                                                                                solo
                                                                                dense
                                                                            ></v-select>
                                                                        </v-col>
                                                                    </v-row>

                                                                    <v-row
                                                                        justify="space-around"
                                                                        no-gutters
                                                                    >
                                                                        <v-col
                                                                            cols="12"
                                                                        >
                                                                            <v-text-field
                                                                                solo
                                                                                label="Service cost"
                                                                                clearable
                                                                                dense
                                                                            ></v-text-field>
                                                                        </v-col>
                                                                    </v-row>

                                                                    <v-row
                                                                        justify="space-around"
                                                                        no-gutters
                                                                    >
                                                                        <v-col
                                                                            cols="12"
                                                                        >
                                                                            <v-textarea
                                                                                solo
                                                                                label="Qualifications"
                                                                                dense
                                                                            >
                                                                            </v-textarea>
                                                                        </v-col>
                                                                    </v-row>

                                                                    <v-row
                                                                        justify="space-around"
                                                                        no-gutters
                                                                    >
                                                                        <v-col
                                                                            cols="12"
                                                                        >
                                                                            <v-text-field
                                                                                solo
                                                                                label="Available contractors"
                                                                                clearable
                                                                                dense
                                                                            ></v-text-field>
                                                                        </v-col>
                                                                    </v-row>
                                                                    <v-card-actions>
                                                                        <v-spacer></v-spacer>
                                                                        

                                                                        <v-btn
                                                                            color="error"
                                                                            dense
                                                                            small
                                                                            dark
                                                                            text
                                                                            @click="deleteItem(item)"
                                                                            justify="space-around"
                                                                            >
                                                                            Delete
                                                                            </v-btn>
                                                                            <v-dialog v-model="dialogDelete" max-width="500px">
                                                                                <v-card>
                                                                                    <v-card-title class="text-h5">Are you sure you want to delete this Agent?</v-card-title>
                                                                                    <v-card-actions>
                                                                                    <v-spacer></v-spacer>
                                                                                    <v-btn color="blue darken-1" text @click="closeDelete">Cancel</v-btn>
                                                                                    <v-btn color="blue darken-1" text @click="editdialog = false">OK</v-btn>
                                                                                    <v-spacer></v-spacer>
                                                                                    </v-card-actions>
                                                                                </v-card>
                                                                            </v-dialog>
                                                                            &nbsp;
                                                                            <v-btn
                                                                            color="#CBAB04"
                                                                            dense
                                                                            small
                                                                            dark
                                                                            text
                                                                            @click="editdialog = false"
                                                                            justify="space-around"
                                                                        >
                                                                            Close
                                                                        </v-btn>

                                                                        &nbsp; &nbsp;
                                                                        <v-btn
                                                                            color="#CBAB04"
                                                                            dense
                                                                            small
                                                                            dark
                                                                            @click="editdialog = false"
                                                                            justify="space-around"
                                                                        >
                                                                            Save
                                                                        </v-btn>
                                                                    </v-card-actions>

                                                            </v-container>
                                                
                                                </v-col>
                                            <!-- </v-responsive> -->
                                        
                                    </v-col>

                                    <v-col cols="9">

                                            <v-col
                                                cols="12"
                                                md="12"
                                                class="mt-3 mx-auto rounded- align-center text-center"
                                            >
                                                <v-img
                                                    src="/images/map.jpg"
                                                ></v-img>
                                            </v-col>
                                    </v-col>
                                    </v-row>
                                </v-card>
                            </v-dialog>
                            </v-row>
                        </template>

                        </v-col>
                    </v-row>

                </v-responsive>
            </v-col>
        

            <v-col cols="7">
                
                <v-col
                    cols="12"
                    class="mt-3 mx-auto rounded- align-center text-center"
                >
                    <v-col
                        cols="8"
                        class="mt-3 mx-auto rounded- align-center text-center"
                    >
                        <v-btn
                            :loading="loading"
                            :disabled="loading"
                            color="#424242"
                            class="white--text"
                            @click="loader = 'loading'"
                            large
                        >
                            Draw proximity
                            <template v-slot:loader>
                                <span class="custom-loader">
                                    <v-icon light>mdi-cached</v-icon>
                                </span>
                            </template>
                        </v-btn>
                    </v-col>

                    <v-img src="/images/map.jpg"></v-img>
                </v-col>
            
        </v-col>
        </v-row>
    </v-card>
</template>




<script>
  export default {
    data: () => ({
        
        dialog: false,
        dialogq: false,
        attrs:false,
        on:false,
        checkbox: false,
        select: [],
        items: [],
        service: [],
        cost: [0],
        subcategory: [0],



      search: '',
      dialogDelete: false,
      editdialog: false,
      role: ['Agent', 'Contractor', 'Charted Engineer'],
          gender: ['Male', 'Female'],
          subcategory:['subcategory 1', 'subcategory 2', 'subcategory 3', 'subcategory 4', 'subcategory 5'],
          show1: false,
          rules: {
            required: value => !!value || 'Required.',
            min: v => v.length >= 8 || 'Min 8 characters',
          },
          services: [],
          svs: [
          { header: 'Group 1' },
          { name: 'Service 1', group: 'Group 1'},
          { name: 'Service 2', group: 'Group 1' },
          { name: 'Service 3', group: 'Group 1'},
          { name: 'Service 4', group: 'Group 1'},
          { divider: true },
          { header: 'Group 2' },
          { name: 'Service 5', group: 'Group 2'},
          { name: 'Service 6', group: 'Group 2' },
          { name: 'Service 7', group: 'Group 2'},
          { name: 'Service 8', group: 'Group 2'},
          { divider: true },
          { header: 'Group 3' },
          { name: 'Service 9', group: 'Group 3'},
          { name: 'Service 10', group: 'Group 3' },
          { name: 'Service 11', group: 'Group 3'},
          { name: 'Service 12', group: 'Group 3'},
        ],
        experience: ['1 - 12 Months', '1 - 2 Years', '2 - 3 Years', '3 - 4 Years', '4 - 5 Years', 'Above 5 years'],
        days: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
          
        time2: null,
        time3: null,
        menu2: false,
        menu3: false,

      
        autoUpdate: true,
        isUpdating: false,

                
  
        watch: {
              isUpdating (val) {
              if (val) {
                  setTimeout(() => (this.isUpdating = false), 3000)
              }
              },
              loader() {
                const l = this.loader;
                this[l] = !this[l];

                setTimeout(() => (this[l] = false), 3000);

                this.loader = null;
            },
            dialog (val) {
                val || this.close()
            },
            dialogDelete (val) {
                val || this.closeDelete()
            },
          },

          headers: [
          { text: 'Sub category', align: 'start', value: 'subcategory', sortable: false },
          {text: 'Services', sortable: false, value: 'sname'},
          { text: 'Services cost', value: 'cost' , sortable: false},
          { text: 'Available Contractors', value: 'count', sortable: false },          
          { text: 'Qualification', value: 'qualification', sortable: false },          
          { text: 'Actions', value: 'actions', sortable: false },
        ],
        editedIndex: -1,

        editedItem: {
        sname: '',
        subcategory: '0',
        cost: '0',
        count: '0',
        
        },
        defaultItem: {
            sname: '',
            subcategory: '0',
            cost: '0',
            count: '0',
        },

          

    }),

    computed: {
      formTitle () {
        return this.editedIndex === -1 ? 'Add Service' : 'Edit Item'
      },
    },

    created () {
      this.initialize()
    },
    
    methods: {
        getColor (subcategory) {
        if (subcategory == 1) return 'red'
        else if (subcategory == 2) return 'green'
        else if (subcategory == 3) return 'orange'
        else return 'blue'
      },

      initialize () {
        this.services = [
          {
            sname: 'Service 1',
            subcategory: '1',
            cost: '3500',
            count: '20',
          },
          
          {
            sname: 'Service 2',
            subcategory: '3',
            cost: '2000',
            count: '31',
          },

          {
            sname: 'Service 3',
            subcategory: '2',
            cost: '2700',
            count: '19',
          },

          {
            sname: 'Service 4',
            subcategory: '1',
            cost: '5400',
            count: '23',
          },

          {
            sname: 'Service 5',
            subcategory: '3',
            cost: '2700',
            count: '41',
          },

          {
            sname: 'Service 6',
            subcategory: '2',
            cost: '3200',
            count: '54',
          },

          {
            sname: 'Service 7',
            subcategory: '1',
            cost: '3600',
            count: '29',
          },

          {
            sname: 'Service 8',
            subcategory: '2',
            cost: '7200',
            count: '46',
          },

          {
            sname: 'Service 9',
            subcategory: '1',
            cost: '2700',
            count: '78',
          },

          {
            sname: 'Service 10',
            subcategory: '3',
            cost: '4600',
            count: '18',
          },

        ]
      },

      editService (item) {
        this.editedIndex = this.services.indexOf(item)
        this.editedItem = Object.assign({}, item)
        this.dialog = true
      },

      editService (item) {
        this.editedIndex = this.services.indexOf(item)
        this.editedItem = Object.assign({}, item)
        this.editdialog = true
      },

      addService (item) {
        this.editedIndex = this.services.indexOf(item)
        this.editedItem = Object.assign({}, item)
        this.editdialog1 = true
      },

      deleteItem (item) {
        this.editedIndex = this.services.indexOf(item)
        this.editedItem = Object.assign({}, item)
        this.dialogDelete = true
      },

      deleteItemConfirm () {
        this.services.splice(this.editedIndex, 1)
        this.closeDelete()
      },

      close () {
        this.dialog = false
        this.$nextTick(() => {
          this.editedItem = Object.assign({}, this.defaultItem)
          this.editedIndex = -1
        })
      },

      closeDelete () {
        this.dialogDelete = false
        this.$nextTick(() => {
          this.editedItem = Object.assign({}, this.defaultItem)
          this.editedIndex = -1
        })
      },

      save () {
        if (this.editedIndex > -1) {
          Object.assign(this.services[this.editedIndex], this.editedItem)
        } else {
          this.services.push(this.editedItem)
        }
        this.close()
      },
    },

  }
</script>