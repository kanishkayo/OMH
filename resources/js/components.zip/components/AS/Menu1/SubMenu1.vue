<template>
    <div>
        <v-container>
        <v-row>
            <v-col cols="12" lx="12" lg="12" md="12" sm="12">
            <h1>Sub Menu 01</h1>
            </v-col>
        </v-row>
        </v-container>
    </div>
</template>
<script>
    export default {

        data() {
            return {

            }
        },

        created(){

        },

        watch: {

        },

        methods: {

        },

        mounted() {

        }
    }
</script>
<style>

</style>
