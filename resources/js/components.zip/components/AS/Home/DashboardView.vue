<template>
    <v-card>
        <v-row>
        <v-col cols="12">
            <v-card>
                <v-responsive
                    class="overflow-y-auto"
                    max-height="661"
                >
                    <v-col cols="12" md="10" class="mt-3 mx-auto rounded- align-center text-center"  style=" background-color: #FAFAFA;" >
                                                
                    </v-col>
                </v-responsive>
            </v-card>
        </v-col>

        </v-row>
    </v-card>
</template>