<template>
  <div>
    <v-navigation-drawer v-model="drawer" color="#3E2723" app clipped dark>
        <v-divider></v-divider>
      <v-list dense rounded background>

        <v-list-item class="px-2">
            <v-list-item-avatar>
              <v-img src="https://randomuser.me/api/portraits/women/85.jpg"></v-img>
            </v-list-item-avatar>
          </v-list-item>

          <v-list-item link>
            <v-list-item-content>
              <v-list-item-title class="text-h6">
                Sandra Adams
              </v-list-item-title>
              <v-list-item-subtitle><strong>sandra@leco.lk</strong></v-list-item-subtitle>
            </v-list-item-content>
          </v-list-item>


        <v-divider></v-divider>

        <v-list-item  to="/leco/dashboard/home" link>
                <v-list-item-content>
                    <v-list-item-title>Home</v-list-item-title>
                </v-list-item-content>
            </v-list-item>
            <v-list-item  to="/leco/dashboard/userRegistration" link>
                <v-list-item-content>
                    <v-list-item-title> User Registration</v-list-item-title>
                </v-list-item-content>
            </v-list-item>
            <v-list-item  to="/leco/dashboard/agent" link>
                <v-list-item-content>
                    <v-list-item-title> Agent </v-list-item-title>
                </v-list-item-content>
            </v-list-item>

            <v-list-item  to="/leco/dashboard/contractor" link>
                <v-list-item-content>
                    <v-list-item-title> Contractor </v-list-item-title>
                </v-list-item-content>
            </v-list-item>

            <v-list-item  to="/leco/dashboard/chartedEng" link>
                <v-list-item-content>
                    <v-list-item-title> Charted Engineers </v-list-item-title>
                </v-list-item-content>
            </v-list-item>

            <v-list-item  to="/leco/dashboard/service" link>
                <v-list-item-content>
                    <v-list-item-title> Services </v-list-item-title>
                </v-list-item-content>
            </v-list-item>

            <v-list-item  to="/leco/dashboard/customer" link>
                <v-list-item-content>
                    <v-list-item-title> Customers </v-list-item-title>
                </v-list-item-content>
            </v-list-item>

      </v-list>
    </v-navigation-drawer>

    <v-app-bar app clipped-left color="#ebb922" dense>
      <v-app-bar-nav-icon @click.stop="drawer = !drawer" />
      <v-toolbar-title class="headline" style="margin-right: 30px">
        <span class="title black--text"> <strong>LANKA ELECTRICITY COMPANY (PVT) LTD </strong></span>
      </v-toolbar-title>
      <v-spacer />
      <!-- <v-toolbar-title class="headline" style="margin-right: 30px">
        <span class="title white--text"> User  </span>
      </v-toolbar-title> -->
      <v-menu left bottom>
        <template v-slot:activator="{ on }">
          <v-btn icon v-on="on">
            <v-icon class="black--text">mdi-account-circle</v-icon>
          </v-btn>
        </template>

        <v-list>
          <v-list-item @click="dialogLogout = true">
            <v-list-item-title>
              <v-icon class="ma-2">mdi-logout</v-icon>Logout
            </v-list-item-title>
          </v-list-item>
        </v-list>
      </v-menu>
    </v-app-bar>

    <!-- ******************* logout user dialog ********************** -->

    <v-dialog v-model="dialogLogout" max-width="290">
      <v-card>
        <v-card-title class="headline">User Logout?</v-card-title>
        <v-card-text>Do you want to logout ?</v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="green darken-1" text @click="dialogLogout = false"
            >Cancel</v-btn
          >

          <v-btn color="red darken-1" text @click="isLogOut()">Logout</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-main>
      <!-- <DashboardView v-if="$route.name == 'DashboardMain'"></DashboardView>
      <SubMenu1 v-if="$route.name == 'SUBMenuList'"></SubMenu1> -->

      <router-view></router-view>

      <!-- <h1>aaaaaa</h1> -->

    </v-main>
  </div>
</template>

<script>
// import DashboardView from "./AS/Home/DashboardView.vue";
// import SubMenu1 from "./AS/Menu1/SubMenu1.vue";
export default {
  name: "DashbordMain",

  components:{
    //   DashboardView,
    //   SubMenu1,
  },

  data: () => ({
    showPassword: false,
    drawer: false,
    dialogLogout: false,
    items: [
      {
        action: "mdi-monitor-dashboard",
        title: "Home",
        active: true,
        items: [
          { subtitle: "Dashboard", routePath: "home" },
        ],
        url: "",
      },
      {
        action: "mdi-clipboard",
        title: "Menu 1",
        active: false,
        items: [
          { subtitle: "Sub Menu 1", routePath: "submenu-list" },

        ],
        url: "",
      },
    ],

  }),
  methods: {
    isLogOut() {
      window.setLogout();
    },
  },
};
</script>
