<template>
    <v-card class="mx-auto">

        <v-tabs color="#CBAB04" dark >
            <v-tab>
                <v-icon left>
                mdi-account-check
                </v-icon>
                Appoint agent
            </v-tab>
            <!-- <v-tab>
                <v-icon left>
                mdi-lock-reset
                </v-icon>
                Reset customer password
            </v-tab> -->

            <v-tab-item>
                <v-card flat>
                    <v-row no-gutters dense>
                        <v-col cols="12" dense>

                            <v-card class="mx-auto">
                                <v-row justify="center" class="spacer" align="center" no-gutters>
                                    <v-col cols="12" class="mt-3 mx-auto rounded- align-center text-center">

                                        <v-container fluid>
                                                <v-row
                                                    justify="space-around"
                                                    no-gutters
                                                >
                                                    <v-col cols="12">
                                                        <v-text-field solo dense label="Account number" clearable> </v-text-field>
                                                    </v-col>
                                                </v-row>


                                                <v-row
                                                justify="space-around"
                                                no-gutters
                                            >
                                                <v-col cols="12">
                                                    <v-text-field solo dense label="Name" clearable> </v-text-field>
                                                </v-col>
                                            </v-row>

                                            <v-row
                                                    justify="space-around"
                                                    no-gutters
                                                >
                                                    <v-col cols="12">
                                                        <v-text-field solo dense label="Contact number" clearable> </v-text-field>
                                                    </v-col>
                                                </v-row>

                                            <v-row
                                                justify="space-around"
                                                no-gutters
                                            >
                                                <v-col cols="12">
                                                    <v-text-field solo dense label="Address" clearable> </v-text-field>
                                                </v-col>
                                            </v-row>
                                            <v-row justify="space-around" no-gutters>
                                                <v-col cols="12">
                                                    <v-autocomplete
                                                        v-model="service"
                                                        :items="svs"
                                                        dense
                                                        chips
                                                        small-chips
                                                        label="services"
                                                        multiple
                                                        solo
                                                        item-text="name"
                                                        item-value="name"
                                                        menu-props="auto"
                                                        hide-details
                                                        single-line

                                                    >
                                                    </v-autocomplete>
                                                </v-col>
                                            </v-row>

                                            <v-row justify="space-around">
                                                <v-col cols="12">
                                                    <v-select
                                                        :items="LocatinList"
                                                        label="Curent Location"
                                                        v-model="curent_location"
                                                        outlined
                                                        dense
                                                        flat
                                                        solo
                                                        class="ma-0"
                                                    ></v-select>
                                                </v-col>
                                            </v-row>





                                        </v-container>
                                    </v-col>

                                    <v-col cols="12" class="mt-3 mx-auto rounded- align-center text-center">
                                        <v-container fluid>
                                            <v-row>
                                                <GmapMap
                                                    style="
                                                        width: 100% !important;
                                                        height: 50vh !important;
                                                    "
                                                    :options="options"
                                                    :center="center"
                                                    :zoom="6.8"
                                                    ref="mapDiv"
                                                >
                                                    <!--<gmap-marker :key="index" v-for="(m, index) in markersSet" :position="m.position" :clickable="true" :icon="m.icon"/>-->
                                                </GmapMap>
                                            </v-row>




                                        </v-container>

                                    </v-col>
                                </v-row>



                                <!-- <v-row justify="center" no-gutters dense>
                                    <v-container fluid>
                                        <v-radio-group v-model="radios">

                                        <template v-slot:label>
                                            <div><strong>Select Service location</strong></div>
                                        </template>
                                        <v-row>
                                            <v-col cols="4">
                                                <v-radio value="Agent location">
                                                    <template v-slot:label>
                                                    <div><strong class="orange--text">Agent </strong>Location</div>
                                                    </template>
                                                </v-radio>
                                            </v-col>
                                            <v-col cols="4">
                                                <v-radio value="Current Location">
                                                    <template v-slot:label>
                                                    <div><strong class="orange--text">Current </strong>Location</div>
                                                    </template>
                                                </v-radio>
                                            </v-col>
                                            <v-col cols="4">
                                                <v-radio value="Select Location">
                                                    <template v-slot:label>
                                                    <div><strong class="orange--text">Select </strong>Location</div>
                                                    </template>
                                                </v-radio>
                                            </v-col>
                                        </v-row>
                                        </v-radio-group>
                                    </v-container>
                                </v-row> -->

                                <v-row justify="space-around"  dense>

                                                    <v-col
                                                        cols="12"
                                                    >

                                                    <v-subheader solo ><h3>Select available dates & time period</h3></v-subheader>

                                                    </v-col>

                                                    <v-col
                                                        cols="4"
                                                    >
                                                        <v-dialog
                                                        v-model="dialogdt"
                                                        width="800"
                                                        >

                                                            <template v-slot:activator="{ on, attrs }">
                                                                <v-btn

                                                                v-bind="attrs"
                                                                v-on="on"
                                                                color="#CBAB04"
                                                                class="#424242--text"
                                                                block
                                                                outlined
                                                                >
                                                                Click Me
                                                                </v-btn>
                                                            </template>


                                                        <v-card>
                                                            <v-card-title class="text-h5 grey lighten-2">
                                                                <v-row justify="space-around" no-gutters>
                                                                    <v-col cols="12"><v-spacer></v-spacer></v-col>
                                                                    <v-col cols="4">
                                                                        <v-subheader solo dense ><strong>Day</strong></v-subheader>
                                                                    </v-col>

                                                                    <v-col cols="4">
                                                                        <v-subheader solo dense><strong>Start time</strong></v-subheader>
                                                                    </v-col>

                                                                    <v-col cols="4">
                                                                        <v-subheader solo dense><strong>End time</strong></v-subheader>
                                                                    </v-col>

                                                                </v-row>
                                                            </v-card-title>

                                                            <v-row justify="space-around" no-gutters>
                                                                <v-row v-for="(
                                                                    singleItem, k
                                                                ) in importPermitMultipleDocAttachments"
                                                                :key="k">
                                                                    <v-col cols="4" class="d-flex">
                                                                        <v-col cols="10">
                                                                            <v-select
                                                                            v-model="days"
                                                                            :items="days"
                                                                            label="Select day"
                                                                            dense
                                                                            menu-props="auto"
                                                                            hide-details
                                                                            single-line

                                                                            ></v-select>
                                                                        </v-col>
                                                                    </v-col>

                                                                    <v-col cols="3.5" class="d-flex">
                                                                        <v-menu
                                                                            ref="menu1"
                                                                            v-model="menu2"
                                                                            :close-on-content-click="false"
                                                                            :nudge-right="40"
                                                                            :return-value.sync="timeStart"
                                                                            transition="scale-transition"
                                                                            offset-y
                                                                            max-width="200px"
                                                                            min-width="200px"
                                                                        >
                                                                            <template v-slot:activator="{ on, attrs }">
                                                                            <v-text-field
                                                                                v-model="timeStart"
                                                                                label="Start time"
                                                                                prepend-icon="mdi-clock-time-four-outline"
                                                                                readonly
                                                                                v-bind="attrs"
                                                                                v-on="on"
                                                                            ></v-text-field>
                                                                            </template>
                                                                            <v-time-picker
                                                                            v-if="menu2"
                                                                            v-model="timeStart"
                                                                            full-width
                                                                            @click:minute="$refs.menu1.save(timeStart)"
                                                                            ></v-time-picker>
                                                                        </v-menu>
                                                                    </v-col>

                                                                    <v-col cols="3.5" class="d-flex">
                                                                        <v-menu
                                                                            ref="menu"
                                                                            v-model="menu3"
                                                                            :close-on-content-click="false"
                                                                            :nudge-right="40"
                                                                            :return-value.sync="time2"
                                                                            transition="scale-transition"
                                                                            offset-y
                                                                            max-width="200px"
                                                                            min-width="200px"
                                                                        >
                                                                            <template v-slot:activator="{ on, attrs }">
                                                                            <v-text-field
                                                                                v-model="time2"
                                                                                label="End time"
                                                                                prepend-icon="mdi-clock-time-four-outline"
                                                                                readonly
                                                                                v-bind="attrs"
                                                                                v-on="on"
                                                                            ></v-text-field>
                                                                            </template>
                                                                            <v-time-picker
                                                                            v-if="menu3"
                                                                            v-model="time2"
                                                                            full-width
                                                                            @click:minute="$refs.menu.save(time2)"
                                                                            ></v-time-picker>
                                                                        </v-menu>
                                                                    </v-col>

                                                                    <v-col cols="1"  class="mt-3 mx-auto rounded- align-center text-center">

                                                                        <v-btn
                                                                            x-small
                                                                            dark
                                                                            color="red darken-4"
                                                                            dense
                                                                            @click="removeImportPermitDoc(k)"
                                                                            v-show="
                                                                                k ||
                                                                                (!k &&
                                                                                    importPermitMultipleDocAttachments.length >
                                                                                        1)
                                                                            "
                                                                        >
                                                                            <v-icon small
                                                                                >mdi-minus</v-icon
                                                                            >
                                                                        </v-btn>

                                                                        <v-btn
                                                                            x-small
                                                                            dark
                                                                            color="green darken-4"
                                                                            dense
                                                                            @click="addImportPermitDoc(k)"
                                                                            v-show="
                                                                                k ==
                                                                                importPermitMultipleDocAttachments.length -
                                                                                    1
                                                                            "
                                                                        >
                                                                            <v-icon small
                                                                                >mdi-plus</v-icon
                                                                            >
                                                                        </v-btn>

                                                                    </v-col>
                                                                </v-row>
                                                            </v-row>


                                                            <v-divider></v-divider>

                                                            <v-card-actions dense>
                                                            <v-spacer></v-spacer>
                                                            <v-btn
                                                                color="#CBAB04"
                                                                dark
                                                                dense
                                                                text
                                                                @click="dialogdt = false"
                                                            >
                                                                Cancel
                                                            </v-btn>

                                                            <v-btn
                                                                color="#CBAB04"
                                                                dark
                                                                dense
                                                                @click="dialogdt = false"
                                                            >
                                                                Save
                                                            </v-btn>
                                                            <v-spacer></v-spacer>
                                                            </v-card-actions>
                                                        </v-card>
                                                        </v-dialog>
                                                    </v-col>

                                </v-row>



                                <v-col
                                    cols="3"
                                    class="mt-3 mx-auto rounded- align-center text-center" justify="space-around" no-gutters
                                >
                                <!-- <v-dialog v-model="dialogsa" persistent>
                                    <template v-slot:activator="{ on, attrs }"> -->
                                        <v-btn
                                            :loading="loading"
                                            :disabled="loading"
                                            color="#424242"
                                            class="white--text"
                                            @click="agentresultDialog = true"
                                            dense
                                        >
                                            Search Agent

                                        </v-btn>
                                </v-col>
                            </v-card>

                            <!-- <v-container grid-list-xl> -->
                                <!-- <v-responsive
                                    class="overflow-y-auto"
                                    max-height="661"
                                > -->

                                    <!-- <v-col
                                        cols="12"
                                        md="10"
                                        class="mt-3 mx-auto rounded- align-center text-center"
                                        style="background-color: #fafafa;"
                                    > -->
                                        <!-- <v-app
                                            id="addAgent"
                                            class="mt-0"
                                        > -->

                                            <!-- <v-container fluid>
                                                    -->
            <!-- </template>
                                                    <v-card>
                                                        <v-row justify="space-around" no-gutters> -->
                                                            <!-- <v-col cols="12"> -->

                                                            <!-- </v-col> -->

                                                            <!-- <v-col cols="7">
                                                                <v-img
                                                                        src="/images/map.jpg"
                                                                    ></v-img>
                                                            </v-col> -->
                                                        <!-- </v-row>
                                                    </v-card>
                                                </v-dialog> -->
            <!--


                                            </v-container> -->


                                        <!-- </v-app>
                                    </v-col> -->
                                <!-- </v-responsive> -->
                            <!-- </v-container> -->

                        </v-col>

                    </v-row>
                </v-card>
            </v-tab-item>

            <v-dialog v-model="agentresultDialog">
                     <v-card class="mx-auto">
                                                <v-card class="t-3 mx-auto rounded- align-center text-center #424242--text text-h4" style="background-color: #CBAB04;" >Available agents </v-card>
                                        <v-row>
                                            <v-col cols="12">
                                                <v-col cols="12" md="8" class="mt-3 mx-auto rounded- align-center text-center" >
                                                    <v-text-field
                                                        v-model="search"
                                                        append-icon="mdi-magnify"
                                                        label="Search agents"
                                                        single-line
                                                        hide-details
                                                    ></v-text-field>
                                                </v-col>

                                                <v-col cols="12" class="mt-3 mx-auto rounded- align-center text-center" >


                                                    <v-data-table
                                                    :headers="headersav"
                                                    :search="search"
                                                    :items-per-page="5"
                                                    :items="availableAgents"
                                                    dense
                                                    class="elevation-1"
                                                    >

                                                    <template v-slot:item.infoav="{ item }">

                                                    <v-dialog
                                                    v-model="dialogav"
                                                    max-width="600px"
                                                    >
                                                    <template v-slot:activator="{ on, attrs }">

                                                        <v-btn
                                                            class="mr-2 black--text"
                                                            @click="dialogav(item)"
                                                            color="#CBAB04"
                                                            v-bind="attrs"
                                                            v-on="on"
                                                            dense                                                                                dark
                                                            x-small
                                                        ><v-icon dense class="white--text">
                                                            mdi-account-clock </v-icon>
                                                            <strong>&nbsp; assign</strong>
                                                        </v-btn>

                                                    </template>
                                                    <v-card>
                                                        <v-card-title class="text-h5">
                                                        Are you sure, you wants to make an appoinment with this agent?
                                                        </v-card-title>

                                                        <v-card-text>
                                                        Let Google help apps determine location. This means sending anonymous location data to Google, even when no apps are running.
                                                        </v-card-text>

                                                        <v-card-actions>
                                                        <v-spacer></v-spacer>

                                                        <v-btn
                                                            color="#CBAB04"
                                                            dense
                                                            small
                                                            dark
                                                            text
                                                            @click="dialogav = false"
                                                        >
                                                            Cancel
                                                        </v-btn>

                                                        <v-btn
                                                            color="#CBAB04"
                                                            dense
                                                            small
                                                            dark
                                                            @click="dialogav = false"
                                                        >
                                                            Yes, Make an appoinment
                                                        </v-btn>
                                                        </v-card-actions>
                                                    </v-card>
                                                    </v-dialog>
                                                    </template>


                                                    <template v-slot:item.ratingav="{ item }">

                                                        <v-dialog
                                                        v-model="dialograv"
                                                        width="600px"
                                                        >
                                                        <template v-slot:activator="{ on, attrs }">

                                                            <v-rating
                                                            v-model="ratingav"
                                                            color="#CBAB04"
                                                            background-color="grey darken-1"
                                                            empty-icon="$ratingFull"
                                                            half-increments
                                                            hover
                                                            x-small
                                                            dense
                                                            ></v-rating>

                                                        </template>
                                                        </v-dialog>
                                                    </template>

                                                    </v-data-table>

                                                </v-col>
                                            </v-col>

                                            <v-col
                                                    cols="8"
                                                    class="mt-3 mx-auto rounded- align-center text-center"
                                                >
                                                    <v-btn
                                                        :loading="loading"
                                                        :disabled="loading"
                                                        color="#424242"
                                                        class="white--text"
                                                        @click="loader = 'loading'"
                                                        dense
                                                    >
                                                        Search More Agents?

                                                    </v-btn>
                                                </v-col>
                                        </v-row>
                                    </v-card>
                                <v-card class="mx-auto">
                                    <v-container grid-list-xl>
                                        <v-card class="t-3 mx-auto rounded- align-center text-center #424242--text text-h4" style="background-color: #CBAB04;" >All agents </v-card>
                                        <v-row  justify="center" no-gutters dense>
                                            <v-col cols="12">
                                                <v-col cols="12" md="8" class="mt-3 mx-auto rounded- align-center text-center" >
                                                    <v-text-field
                                                        v-model="search"
                                                        append-icon="mdi-magnify"
                                                        label="Search agents"
                                                        single-line
                                                        hide-details
                                                    ></v-text-field>

                                                </v-col>

                                                <v-row class="pa-5">

                                                    <v-col cols="4">
                                                        <v-select
                                                            v-model="avec"
                                                            :items="ave"
                                                            label="Search by availability"
                                                            solo
                                                            dense
                                                        ></v-select>
                                                    </v-col>
                                                    <v-col cols="4">
                                                        <v-select
                                                            v-model="rate"
                                                            :items="ratingf"
                                                            label="Search by rating"
                                                            solo
                                                            dense
                                                        ></v-select>
                                                    </v-col>

                                                    <v-col cols="3" >
                                                        <v-btn
                                                            :loading="loading"
                                                            :disabled="loading"
                                                            color="#424242"
                                                            class="white--text mt-1"
                                                            @click="loader = 'loading'"

                                                            dense
                                                        >
                                                            Filter
                                                            <template v-slot:loader>
                                                                <span class="custom-loader">
                                                                    <v-icon light>mdi-cached</v-icon>
                                                                </span>
                                                            </template>
                                                        </v-btn>
                                                    </v-col>
                                                </v-row>

                                                <v-col cols="12" class="mt-3 mx-auto rounded- align-center text-center" >

                                                    <v-data-table
                                                    :headers="headerssm"
                                                    :search="search"
                                                    :items-per-page="5"
                                                    :items="allAgents"
                                                    dense
                                                    class="elevation-1"
                                                    >

                                                    <template v-slot:item.infosh="{ item }">

                                                    <v-dialog
                                                    v-model="dialogsh"
                                                    width="600px"
                                                    >
                                                    <template v-slot:activator="{ on, attrs }">

                                                        <v-btn
                                                            class="mr-2 black--text"
                                                            @click="dialogsh(item)"
                                                            color="#CBAB04"
                                                            v-bind="attrs"
                                                            v-on="on"
                                                            dense                                                                                dark
                                                            x-small
                                                        ><v-icon dense class="white--text">
                                                            mdi-account-clock </v-icon>
                                                            <strong>&nbsp; assign</strong>
                                                        </v-btn>

                                                    </template>
                                                    <v-card>
                                                        <v-card-title class="text-h5">
                                                        Are you sure, you wants to make an appoinment with this agent?
                                                        </v-card-title>

                                                        <v-card-text>
                                                        Let Google help apps determine location. This means sending anonymous location data to Google, even when no apps are running.
                                                        </v-card-text>

                                                        <v-card-actions>
                                                        <v-spacer></v-spacer>

                                                        <v-btn
                                                            color="#CBAB04"
                                                            dense
                                                            small
                                                            dark
                                                            text
                                                            @click="dialogsh = false"
                                                        >
                                                            Cancel
                                                        </v-btn>

                                                        <v-btn
                                                            color="#CBAB04"
                                                            dense
                                                            small
                                                            dark
                                                            @click="dialogsh = false"
                                                        >
                                                            Yes, Make an appoinment
                                                        </v-btn>
                                                        </v-card-actions>
                                                    </v-card>
                                                    </v-dialog>
                                                    </template>

                                                    <template v-slot:item.agentinfo="{ item }">

                                                        <v-dialog
                                                        v-model="dialogc"
                                                        width="600px"
                                                        >
                                                        <template v-slot:activator="{ on, attrs }">

                                                            <v-icon

                                                            class="mr-2"
                                                            @click="dialogc(item)"
                                                            color="#CBAB04"
                                                            v-bind="attrs"
                                                            v-on="on"
                                                            fab
                                                            dark
                                                        >
                                                        mdi-account-details
                                                        </v-icon>

                                                        </template>
                                                            <v-card>
                                                                <v-card-title>
                                                                    <span class="text-h5">Customer details</span>
                                                                </v-card-title>

                                                                <v-card-text>
                                                                Lorem ipsum dolor sit amet, semper quis, sapien id natoque elit. Nostra urna at, magna at neque sed sed ante imperdiet, dolor mauris cursus velit, velit non, sem nec. Volutpat sem ridiculus placerat leo, augue in, duis erat proin condimentum in a eget, sed fermentum sed vestibulum varius ac, vestibulum volutpat orci ut elit eget tortor. Ultrices nascetur nulla gravida ante arcu. Pharetra rhoncus morbi ipsum, nunc tempor debitis, ipsum pellentesque, vitae id quam ut mauris dui tempor, aptent non. Quisque turpis. Phasellus quis lectus luctus orci eget rhoncus. Amet donec vestibulum mattis commodo, nulla aliquet, nibh praesent, elementum nulla. Sit lacus pharetra tempus magna neque pellentesque, nulla vel erat.
                                                                Justo ex quisque nulla accusamus venenatis, sed quis. Nibh phasellus gravida metus in, fusce aenean ut erat commodo eros. Ut turpis, dui integer, nonummy pede placeat nec in sit leo. Faucibus porttitor illo taciti odio, amet viverra scelerisque quis quis et tortor, curabitur morbi a. Enim tempor at, rutrum elit condimentum, amet rutrum vitae tempor torquent nunc. Praesent vestibulum integer maxime felis. Neque aenean quia vitae nostra, tempus elit enim id dui, at egestas pulvinar. Integer libero vestibulum, quis blandit scelerisque mattis fermentum nulla, tortor donec vestibulum dolor amet eget, elit nullam. Aliquam leo phasellus aliquam curabitur metus a, nulla justo mattis duis interdum vel, mollis vitae et id, vestibulum erat ridiculus sit pulvinar justo sed. Vehicula convallis, et nulla wisi, amet vestibulum risus, quam ac egestas.

                                                                </v-card-text>

                                                                <v-card-actions>
                                                                <v-spacer></v-spacer>
                                                                <v-btn
                                                                    color="#CBAB04"
                                                                    dark
                                                                    x-small
                                                                    dense
                                                                    @click="dialogc = false"
                                                                    class="mr-2"
                                                                    text
                                                                >
                                                                    Close
                                                                </v-btn>

                                                                <v-btn
                                                                    color="#CBAB04"
                                                                    dark
                                                                    x-small
                                                                    dense
                                                                    @click="dialogc = false"
                                                                    class="mr-2"
                                                                >
                                                                    Save
                                                                </v-btn>

                                                                </v-card-actions>
                                                            </v-card>
                                                        </v-dialog>

                                                    </template>

                                                    <template v-slot:item.ratingsh="{ item }">

                                                        <v-dialog
                                                        v-model="dialogr"
                                                        width="600px"
                                                        >
                                                        <template v-slot:activator="{ on, attrs }">

                                                            <v-rating
                                                            v-model="ratingsh"
                                                            color="#CBAB04"
                                                            background-color="grey darken-1"
                                                            empty-icon="$ratingFull"
                                                            half-increments
                                                            hover
                                                            x-small
                                                            dense
                                                            ></v-rating>

                                                        </template>
                                                        </v-dialog>
                                                    </template>

                                                    </v-data-table>

                                                    <!-- <v-data-table
                                                    :headers="headers"
                                                    :items="customer"
                                                    :search="search"
                                                    :items-per-page="7"
                                                    dense
                                                    class="elevation-1"
                                                    >

                                                    <template v-slot:item.request="{ item }">

                                                        <v-dialog
                                                        v-model="dialogsh"
                                                        width="600px"
                                                        >
                                                        <template v-slot:activator="{ on, attrs }">

                                                            <v-icon

                                                                class="mr-2"
                                                                @click="dialogsh(item)"
                                                                color="info"
                                                                v-bind="attrs"
                                                                v-on="on"
                                                                fab
                                                                dark
                                                                dense
                                                                x-small
                                                            >
                                                                mdi-information-variant
                                                            </v-icon>

                                                        </template>
                                                        <v-card>
                                                            <v-card-title>
                                                            <span class="text-h5">Use Google's location service?</span>
                                                            </v-card-title>
                                                            <v-card-text>
                                                            Lorem ipsum dolor sit amet, semper quis, sapien id natoque elit. Nostra urna at, magna at neque sed sed ante imperdiet, dolor mauris cursus velit, velit non, sem nec. Volutpat sem ridiculus placerat leo, augue in, duis erat proin condimentum in a eget, sed fermentum sed vestibulum varius ac, vestibulum volutpat orci ut elit eget tortor. Ultrices nascetur nulla gravida ante arcu. Pharetra rhoncus morbi ipsum, nunc tempor debitis, ipsum pellentesque, vitae id quam ut mauris dui tempor, aptent non. Quisque turpis. Phasellus quis lectus luctus orci eget rhoncus. Amet donec vestibulum mattis commodo, nulla aliquet, nibh praesent, elementum nulla. Sit lacus pharetra tempus magna neque pellentesque, nulla vel erat.
                                                            Justo ex quisque nulla accusamus venenatis, sed quis. Nibh phasellus gravida metus in, fusce aenean ut erat commodo eros. Ut turpis, dui integer, nonummy pede placeat nec in sit leo. Faucibus porttitor illo taciti odio, amet viverra scelerisque quis quis et tortor, curabitur morbi a. Enim tempor at, rutrum elit condimentum, amet rutrum vitae tempor torquent nunc. Praesent vestibulum integer maxime felis. Neque aenean quia vitae nostra, tempus elit enim id dui, at egestas pulvinar. Integer libero vestibulum, quis blandit scelerisque mattis fermentum nulla, tortor donec vestibulum dolor amet eget, elit nullam. Aliquam leo phasellus aliquam curabitur metus a, nulla justo mattis duis interdum vel, mollis vitae et id, vestibulum erat ridiculus sit pulvinar justo sed. Vehicula convallis, et nulla wisi, amet vestibulum risus, quam ac egestas.

                                                            </v-card-text>
                                                            <v-card-actions>
                                                            <v-spacer></v-spacer>
                                                            <v-btn
                                                                color="red darken-1"
                                                                text
                                                                @click="dialogsh = false"
                                                            >
                                                                Close
                                                            </v-btn>
                                                            <v-btn
                                                                color="green darken-1"
                                                                text
                                                                @click="dialogsh = false"
                                                            >
                                                                Agree
                                                            </v-btn> -->
                                                            <!-- </v-card-actions>
                                                        </v-card>
                                                        </v-dialog>
                                                    </template>

                                                    <template v-slot:item.ratingsh="{ item }">

                                                        <v-dialog
                                                        v-model="dialogr"
                                                        width="600px"
                                                        >
                                                            <template v-slot:activator="{ on, attrs }">

                                                                <v-rating
                                                                v-model="ratingsh"
                                                                color="yellow darken-3"
                                                                background-color="grey darken-1"
                                                                empty-icon="$ratingFull"
                                                                half-increments
                                                                hover
                                                                x-small
                                                                ></v-rating>

                                                            </template>

                                                        </v-dialog>

                                                    </template>



                                                    </v-data-table> -->
                                                </v-col>




                                            </v-col>
                                        </v-row>

                                    </v-container>
                                </v-card>
            </v-dialog>
        </v-tabs>
    </v-card>

</template>

<script>

export default {
    data: () => ({
        center: { lat: 7.9708759, lng: 80.2615532 },
            GMap: null,
        dialog: false,
        dialogsh: false,
        dialogav: false,
        dialogc: false,
        dialogr: false,
        dialogs: false,
        dialograv: false,
        dialogsa: false,
        dialogdt: false,
        dialogma: false,
        infosh: false,
        infoav: false,
        editdialog: false,
        avatar: false,
        radios: null,
        attrs:false,
        on:false,
        select: [],
        items: [],
        phone: [0],
        rating: 4.5,
        ratingsh: 3,
        ratingav:4,
        LocatinList:["Current location", "Select location"],
        curent_location:"",
        slocation: ["Agent location", "Current location", "Select location"],
        ratingf:["1","2","3","4","5"],
        rate: "",
        avec: "",
        ave: ["Available", "Not available"],
        dialogDelete: false,
        search: "",
        role: ["Agent", "Contractor", "Charted Engineer"],
        gender: ["Male", "Female"],
        show1: false,
        rules: {
            required: (value) => !!value || "Required.",
            min: (v) => v.length >= 8 || "Min 8 characters",
        },
        service: [],
        location:"",
        locationList:[],
        svs: [
            { header: "Group 1" },
            { name: "Service 1", group: "Group 1" },
            { name: "Service 2", group: "Group 1" },
            { name: "Service 3", group: "Group 1" },
            { name: "Service 4", group: "Group 1" },
            { divider: true },
            { header: "Group 2" },
            { name: "Service 5", group: "Group 2" },
            { name: "Service 6", group: "Group 2" },
            { name: "Service 7", group: "Group 2" },
            { name: "Service 8", group: "Group 2" },
            { divider: true },
            { header: "Group 3" },
            { name: "Service 9", group: "Group 3" },
            { name: "Service 10", group: "Group 3" },
            { name: "Service 11", group: "Group 3" },
            { name: "Service 12", group: "Group 3" },
        ],
        experience: [
            "1 - 12 Months",
            "1 - 2 Years",
            "2 - 3 Years",
            "3 - 4 Years",
            "4 - 5 Years",
            "Above 5 years",
        ],
        days: [
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday",
            "Saturday",
            "Sunday",
        ],

        importPermitMultipleDocAttachments: [
                {
                    days: "",
                    time2: null,
                    timeStart: "",
                },
            ],

          days: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Satuday' ],
          years: ['1 Years', '2 Years', '3 Years', '4 Years', '5 Years', '6 Years', '7 Years', '8 Years', '9 Years', '10 Years', '11 Years', '12 Years', '13 Years', '14 Years', '15 Years', '16 Years', '17 Years', '18 Years', '19 Years','20 Years'],
          months: ['1 Months', '2 Months', '3 Months', '4 Months', '5 Months', '6 Months', '7 Months', '8 Months', '9 Months', '10 Months', '11 Months'],


          menu2: false,
          menu3: false,
          time: null,
          time2: null,
          timeStart:"",

        autoUpdate: true,
        isUpdating: false,

        loader: null,
        loading: false,

        watch: {
            isUpdating(val) {
                if (val) {
                    setTimeout(() => (this.isUpdating = false), 3000);
                }
            },
            loader() {
                const l = this.loader;
                this[l] = !this[l];

                setTimeout(() => (this[l] = false), 3000);

                this.loader = null;
            },
            dialog (val) {
                val || this.close()
            },
            dialogDelete (val) {
                val || this.closeDelete()
            },
        },

        headers: [
          {
          text: 'Account number',
          align: 'start',
          sortable: false,
          value: 'accid'
          },
          { text: 'Contact No', value: 'phone', sortable: false },
          { text: 'Date', value: 'day', sortable: false },
          { text: 'Services', value: 'service', sortable: false },
          { text: 'Actions', value: 'actions', sortable: false },
        ],

        headersav:[{text: 'Agent name',
          align: 'start',
          sortable: false,
          value: 'nameav'
          },
          { text: 'Distance', value: 'distanceav' , sortable: false},
          { text: 'Rating', value: 'ratingav', sortable: false },
          { text: 'Action', value: 'infoav', sortable: false },],

        headerssm:[
          {text: 'Agent name',
          align: 'start',
          sortable: false,
          value: 'name'
          },
          { text: 'Availability', value: 'availability' , sortable: false},
          { text: 'Rating', value: 'ratingsh', sortable: false },
          { text: 'Action', value: 'infosh', sortable: false },],


            editedItem: {
                nameav: '',
                ratingav: '',
                distanceav: '',

            },
            defaultItem: {
                nameav: '',
                ratingav: '',
                distanceav: '',
            },

        agents: [],
        editedIndex: -1,

        editedItem: {
            nameav: '',
            ratingav: '',
            availability: '',

        },
        defaultItem: {
            nameav: '',
            ratingav: '',
            availability: '',
        },
        agentresultDialog:false

    }),

    computed: {
      formTitle () {
        return this.editedIndex === -1 ? 'Add Agent' : 'Edit Item'
      },
    },

    created () {
      this.initialize()
    },

    methods: {
        addImportPermitDoc(index) {
            this.importPermitMultipleDocAttachments.push({
                days: "",
                time2: "",
                timeStart: "",
            });
        },

        removeImportPermitDoc(index) {
            this.importPermitMultipleDocAttachments.splice(index, 1);
        },
      initialize () {
        this.agents = [
          {
            accid: '222',
            phone: '0711111111 ',
            day: '2/2/2023',
          },
          {
            accid: '223',
            phone: '0711234567 ',
            day: '2/2/2023',
          },
          {
            accid: '224',
            phone: '0475656432',
            day: '3/2/2023',
          },
          {
            accid: '225',
            phone: '0765445678 ',
            day: '4/2/2023',
          },
          {
            accid: '226',
            phone: '0745676589',
            day: '5/2/2023',
          },
          {
            accid: '227',
            phone: '071126666 ',
            day: '5/2/2023',
          },
          {
            accid: '228',
            phone: '0786572829',
            day: '7/2/2023',
          },
          {
            accid: '229',
            phone: '0711234563',
            day: '8/2/2023',
          },
          {
            accid: '230',
            phone: '0775674563',
            day: '8/2/2023',

          },
          {
            accid: '231',
            phone: '0704567892',
            day: '8/2/2023',

          },
        ]
        this.availableAgents = [
          {
            nameav: 'CelaTa Leco',
            distanceav: '3 Km',

          },

          {
            nameav: 'Dasun Shanaka',
            distanceav: '2 Km',

          },

          {
            nameav: 'Savin Sathsara',
            distanceav: '5.36 Km',

          },

          {
            nameav: 'Virat Kohli',
            distanceav: '4.67 Km',

          },

          {
            nameav: 'Kaveen Savindra',
            distanceav: '1.67 Km',

          },

          {
            nameav: 'Praveena Leo',
            distanceav: '4.82 Km',

          },

          {
            nameav: 'Uvindu Rihan',
            distanceav: '3 Km',

          },

          {
            nameav: 'Indika Bandara',
            distanceav: '2.7 Km',

          },

          {
            nameav: 'Pahan Ransilu',
            distanceav: '1.8 Km',

          },

          {
            nameav: 'Hiran Kavinga',
            distanceav: '4.3 Km',

          },



        ]
        this.allAgents = [
          {
            name: 'CelaTa Leco',
            availability: 'Available',

          },

          {
            name: 'Dasun Shanaka',
            availability: 'Available',

          },

          {
            name: 'Savin Sathsara',
            availability: 'Available',

          },

          {
            name: 'Virat Kohli',
            availability: 'Available',

          },

          {
            name: 'Kaveen Savindra',
            availability: 'Not Available',

          },

          {
            name: 'Praveena Leo',
            availability: 'Not Available ',

          },

          {
            name: 'Uvindu Rihan',
            availability: 'Available',

          },

          {
            name: 'Indika Bandara',
            availability: 'Not Available',

          },

          {
            name: 'Pahan Ransilu',
            availability: 'Available',

          },

          {
            name: 'Hiran Kavinga',
            availability: 'Available',

          },



        ]
      },

      editItem (item) {
        this.editedIndex = this.agents.indexOf(item)
        this.editedItem = Object.assign({}, item)
        this.dialog = true
      },

      editAgent (item) {
        this.editedIndex = this.agents.indexOf(item)
        this.editedItem = Object.assign({}, item)
        this.editdialog = true
      },

      deleteItem (item) {
        this.editedIndex = this.agents.indexOf(item)
        this.editedItem = Object.assign({}, item)
        this.dialogDelete = true
      },

      deleteItemConfirm () {
        this.agents.splice(this.editedIndex, 1)
        this.closeDelete()
      },

      close () {
        this.dialog = false
        this.$nextTick(() => {
          this.editedItem = Object.assign({}, this.defaultItem)
          this.editedIndex = -1
        })
      },

      closeDelete () {
        this.dialogDelete = false
        this.$nextTick(() => {
          this.editedItem = Object.assign({}, this.defaultItem)
          this.editedIndex = -1
        })
      },

      save () {
        if (this.editedIndex > -1) {
          Object.assign(this.agents[this.editedIndex], this.editedItem)
        } else {
          this.agents.push(this.editedItem)
        }
        this.close()
      },
    },

};

</script>

<style>
.parallax {
  min-height: 600vh;
  display: flex;
  align-items: center;
}
.custom-loader {
    animation: loader 1s infinite;
    display: flex;
}
.bg {
    background-image: url("/images/profile_bg.jpg");
    background-size: cover;
    background-position: center center;
 }
@-moz-keyframes loader {
    from {
        transform: rotate(0);
    }
    to {
        transform: rotate(360deg);
    }
}
@-webkit-keyframes loader {
    from {
        transform: rotate(0);
    }
    to {
        transform: rotate(360deg);
    }
}
@-o-keyframes loader {
    from {
        transform: rotate(0);
    }
    to {
        transform: rotate(360deg);
    }
}
@keyframes loader {
    from {
        transform: rotate(0);
    }
    to {
        transform: rotate(360deg);
    }
}
/*
.data-table{
    font-family: Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 90%;
    margin: 5px;
    font-size: 14px;
}

.data-table td, .data-table th {
    border: 1px solid #ddd;
    padding: 8px;
}

.data-table tr:nth-child(even){background-color: #f2f2f2;}

.data-table tr:hover {background-color: #ddd;}

.data-table th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #3490dc;
    color: white;
}
.data-table td {
    color: black;
} */

</style>

